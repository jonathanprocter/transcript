# Therapy Transcript Processor - Production Deployment Guide

This comprehensive guide documents the complete production deployment process for the Therapy Transcript Processor web application. It consolidates all deployment steps, configurations, and best practices to ensure a secure, reliable, and HIPAA-compliant production environment.

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Infrastructure Setup](#infrastructure-setup)
4. [Application Deployment](#application-deployment)
5. [Domain and SSL Configuration](#domain-and-ssl-configuration)
6. [Security Implementation](#security-implementation)
7. [Backup and Monitoring](#backup-and-monitoring)
8. [Maintenance Procedures](#maintenance-procedures)
9. [Troubleshooting](#troubleshooting)
10. [Compliance Documentation](#compliance-documentation)

## Overview

The Therapy Transcript Processor is a web application that transforms therapy session transcripts into comprehensive clinical progress notes using AI. This deployment guide ensures the application is deployed in a secure, scalable, and HIPAA-compliant environment.

### Architecture Diagram

```
                                  ┌─────────────────┐
                                  │   CloudFront    │
                                  │      CDN        │
                                  └────────┬────────┘
                                           │
                                           ▼
┌─────────────────┐              ┌─────────────────┐
│  Route 53 DNS   │◄────────────►│ Application Load│
└─────────────────┘              │    Balancer     │
                                 └────────┬────────┘
                                          │
                 ┌────────────────────────┼────────────────────────┐
                 │                        │                        │
                 ▼                        ▼                        ▼
        ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
        │  EC2 Instance   │     │  EC2 Instance   │     │  EC2 Instance   │
        │  (Frontend +    │     │  (Frontend +    │     │  (Frontend +    │
        │   Backend)      │     │   Backend)      │     │   Backend)      │
        └────────┬────────┘     └────────┬────────┘     └────────┬────────┘
                 │                       │                       │
                 └───────────────────────┼───────────────────────┘
                                         │
                                         ▼
                               ┌─────────────────┐
                               │   MongoDB Atlas  │
                               │   (Database)    │
                               └────────┬────────┘
                                        │
                                        ▼
                               ┌─────────────────┐
                               │   S3 Buckets    │
                               │  (File Storage) │
                               └─────────────────┘
```

## Prerequisites

Before beginning the deployment process, ensure you have:

1. AWS account with administrative access
2. Domain name for the application (therapytranscriptprocessor.com)
3. OpenAI and/or Anthropic API keys
4. Application source code and dependencies
5. SSL certificate (to be obtained through AWS Certificate Manager)
6. HIPAA compliance requirements documentation

## Infrastructure Setup

### VPC Configuration

```bash
# Create VPC
aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=therapy-transcript-processor-vpc}]'

# Create subnets (in different availability zones)
aws ec2 create-subnet --vpc-id vpc-xxxxxxxx --cidr-block 10.0.1.0/24 --availability-zone us-east-1a --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=therapy-transcript-processor-subnet-1a}]'
aws ec2 create-subnet --vpc-id vpc-xxxxxxxx --cidr-block 10.0.2.0/24 --availability-zone us-east-1b --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=therapy-transcript-processor-subnet-1b}]'

# Create internet gateway
aws ec2 create-internet-gateway --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=therapy-transcript-processor-igw}]'
aws ec2 attach-internet-gateway --internet-gateway-id igw-xxxxxxxx --vpc-id vpc-xxxxxxxx

# Create route table
aws ec2 create-route-table --vpc-id vpc-xxxxxxxx --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=therapy-transcript-processor-rt}]'
aws ec2 create-route --route-table-id rtb-xxxxxxxx --destination-cidr-block 0.0.0.0/0 --gateway-id igw-xxxxxxxx

# Associate route table with subnets
aws ec2 associate-route-table --route-table-id rtb-xxxxxxxx --subnet-id subnet-xxxxxxxx
aws ec2 associate-route-table --route-table-id rtb-xxxxxxxx --subnet-id subnet-yyyyyyyy
```

### Security Groups

```bash
# Create security group for load balancer
aws ec2 create-security-group --group-name therapy-transcript-processor-lb-sg --description "Security group for load balancer" --vpc-id vpc-xxxxxxxx
aws ec2 authorize-security-group-ingress --group-id sg-xxxxxxxx --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-id sg-xxxxxxxx --protocol tcp --port 443 --cidr 0.0.0.0/0

# Create security group for EC2 instances
aws ec2 create-security-group --group-name therapy-transcript-processor-ec2-sg --description "Security group for EC2 instances" --vpc-id vpc-xxxxxxxx
aws ec2 authorize-security-group-ingress --group-id sg-yyyyyyyy --protocol tcp --port 3000 --source-group sg-xxxxxxxx
aws ec2 authorize-security-group-ingress --group-id sg-yyyyyyyy --protocol tcp --port 3001 --source-group sg-xxxxxxxx
aws ec2 authorize-security-group-ingress --group-id sg-yyyyyyyy --protocol tcp --port 22 --cidr YOUR_IP_ADDRESS/32

# Create security group for MongoDB
aws ec2 create-security-group --group-name therapy-transcript-processor-mongodb-sg --description "Security group for MongoDB" --vpc-id vpc-xxxxxxxx
aws ec2 authorize-security-group-ingress --group-id sg-zzzzzzzz --protocol tcp --port 27017 --source-group sg-yyyyyyyy
```

### EC2 Instances

```bash
# Create EC2 instances
aws ec2 run-instances --image-id ami-xxxxxxxxxxxxxxxxx --count 3 --instance-type t3.medium --key-name your-key-pair --security-group-ids sg-yyyyyyyy --subnet-id subnet-xxxxxxxx --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=therapy-transcript-processor-1}]' --user-data file://ec2-user-data.sh
```

Content of `ec2-user-data.sh`:
```bash
#!/bin/bash
# Update system
apt-get update
apt-get upgrade -y

# Install dependencies
apt-get install -y docker.io docker-compose git nginx certbot python3-certbot-nginx

# Enable and start Docker
systemctl enable docker
systemctl start docker

# Add ubuntu user to docker group
usermod -aG docker ubuntu

# Clone application repository
git clone https://github.com/your-org/therapy-transcript-processor.git /home/ubuntu/therapy-transcript-processor
chown -R ubuntu:ubuntu /home/ubuntu/therapy-transcript-processor

# Set up application
cd /home/ubuntu/therapy-transcript-processor
docker-compose up -d
```

### Load Balancer Setup

```bash
# Create target group
aws elbv2 create-target-group --name therapy-transcript-processor-tg --protocol HTTP --port 3000 --vpc-id vpc-xxxxxxxx --health-check-path /health --health-check-protocol HTTP

# Register targets
aws elbv2 register-targets --target-group-arn arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/therapy-transcript-processor-tg/xxxxxxxxxxxxxxxx --targets Id=i-xxxxxxxxxxxxxxxxx Id=i-yyyyyyyyyyyyyyyyy Id=i-zzzzzzzzzzzzzzzzz

# Create load balancer
aws elbv2 create-load-balancer --name therapy-transcript-processor-lb --subnets subnet-xxxxxxxx subnet-yyyyyyyy --security-groups sg-xxxxxxxx --type application

# Create listeners
aws elbv2 create-listener --load-balancer-arn arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/therapy-transcript-processor-lb/xxxxxxxxxxxxxxxx --protocol HTTPS --port 443 --certificates CertificateArn=arn:aws:acm:us-east-1:123456789012:certificate/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/therapy-transcript-processor-tg/xxxxxxxxxxxxxxxx

aws elbv2 create-listener --load-balancer-arn arn:aws:elasticloadbalancing:us-east-1:123456789012:loadbalancer/app/therapy-transcript-processor-lb/xxxxxxxxxxxxxxxx --protocol HTTP --port 80 --default-actions Type=redirect,RedirectConfig="{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}"
```

### Database Setup (MongoDB Atlas)

1. Create a MongoDB Atlas account if you don't have one
2. Create a new project for the application
3. Build a new cluster (M10 or higher recommended for production)
4. Configure network access to allow connections from EC2 security group
5. Create a database user with appropriate permissions
6. Get the connection string for the application

## Application Deployment

### Backend Configuration

Create `.env` file in the backend directory:

```
NODE_ENV=production
PORT=3001
MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/therapy-transcript-processor?retryWrites=true&w=majority
JWT_SECRET=your-secure-jwt-secret
OPENAI_API_KEY=sk-your-openai-api-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-api-key
ENCRYPTION_KEY=your-secure-encryption-key
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1
S3_BUCKET=therapy-transcript-processor-files
```

### Docker Compose Setup

Create `docker-compose.yml` file:

```yaml
version: '3'

services:
  backend:
    build: ./backend
    restart: always
    ports:
      - "3001:3001"
    env_file:
      - ./backend/.env
    volumes:
      - ./backend:/app
      - /app/node_modules
    networks:
      - app-network

  frontend:
    build: ./frontend
    restart: always
    ports:
      - "3000:3000"
    depends_on:
      - backend
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
```

### Deployment Script

Create `deploy.sh` script:

```bash
#!/bin/bash

# Pull latest code
git pull origin main

# Build and start containers
docker-compose down
docker-compose build
docker-compose up -d

# Check container status
docker-compose ps
```

Make the script executable:
```bash
chmod +x deploy.sh
```

## Domain and SSL Configuration

### Domain Registration

1. Register the domain through AWS Route 53:
   ```bash
   aws route53domains register-domain --domain-name therapytranscriptprocessor.com --duration-in-years 1 --auto-renew --admin-contact ... --registrant-contact ... --tech-contact ...
   ```

2. Create a hosted zone:
   ```bash
   aws route53 create-hosted-zone --name therapytranscriptprocessor.com --caller-reference $(date +%s)
   ```

3. Configure DNS records:
   ```bash
   aws route53 change-resource-record-sets --hosted-zone-id YOUR_HOSTED_ZONE_ID --change-batch '{
     "Changes": [
       {
         "Action": "CREATE",
         "ResourceRecordSet": {
           "Name": "therapytranscriptprocessor.com",
           "Type": "A",
           "AliasTarget": {
             "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
             "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
             "EvaluateTargetHealth": true
           }
         }
       },
       {
         "Action": "CREATE",
         "ResourceRecordSet": {
           "Name": "www.therapytranscriptprocessor.com",
           "Type": "A",
           "AliasTarget": {
             "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
             "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
             "EvaluateTargetHealth": true
           }
         }
       },
       {
         "Action": "CREATE",
         "ResourceRecordSet": {
           "Name": "api.therapytranscriptprocessor.com",
           "Type": "A",
           "AliasTarget": {
             "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
             "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
             "EvaluateTargetHealth": true
           }
         }
       }
     ]
   }'
   ```

### SSL Certificate

1. Request an SSL certificate:
   ```bash
   aws acm request-certificate --domain-name therapytranscriptprocessor.com --validation-method DNS --subject-alternative-names www.therapytranscriptprocessor.com api.therapytranscriptprocessor.com
   ```

2. Create validation records:
   ```bash
   # Get certificate details
   aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN

   # Create validation records in Route 53
   aws route53 change-resource-record-sets --hosted-zone-id YOUR_HOSTED_ZONE_ID --change-batch '{
     "Changes": [
       {
         "Action": "CREATE",
         "ResourceRecordSet": {
           "Name": "VALIDATION_CNAME_NAME",
           "Type": "CNAME",
           "TTL": 300,
           "ResourceRecords": [
             {
               "Value": "VALIDATION_CNAME_VALUE"
             }
           ]
         }
       }
     ]
   }'
   ```

3. Wait for certificate validation:
   ```bash
   aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN
   ```

## Security Implementation

### HIPAA Compliance Measures

1. **Encryption at Rest:**
   - Enable encryption for S3 buckets:
     ```bash
     aws s3api put-bucket-encryption --bucket therapy-transcript-processor-files --server-side-encryption-configuration '{
       "Rules": [
         {
           "ApplyServerSideEncryptionByDefault": {
             "SSEAlgorithm": "AES256"
           }
         }
       ]
     }'
     ```
   - MongoDB Atlas provides encryption at rest by default

2. **Encryption in Transit:**
   - SSL/TLS for all connections
   - HTTPS-only access enforced through load balancer

3. **Access Controls:**
   - Implement IAM roles and policies:
     ```bash
     aws iam create-role --role-name therapy-transcript-processor-role --assume-role-policy-document file://trust-policy.json
     aws iam put-role-policy --role-name therapy-transcript-processor-role --policy-name therapy-transcript-processor-policy --policy-document file://policy.json
     ```

4. **Audit Logging:**
   - Enable CloudTrail:
     ```bash
     aws cloudtrail create-trail --name therapy-transcript-processor-trail --s3-bucket-name therapy-transcript-processor-logs --is-multi-region-trail
     aws cloudtrail start-logging --name therapy-transcript-processor-trail
     ```

5. **Business Associate Agreements (BAAs):**
   - Sign BAAs with AWS and other service providers

### Security Headers

Configure Nginx with security headers:

```nginx
server {
    listen 80;
    server_name therapytranscriptprocessor.com www.therapytranscriptprocessor.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name therapytranscriptprocessor.com www.therapytranscriptprocessor.com;

    ssl_certificate /etc/letsencrypt/live/therapytranscriptprocessor.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/therapytranscriptprocessor.com/privkey.pem;
    
    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self' https://api.openai.com https://api.anthropic.com; frame-ancestors 'none';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 443 ssl;
    server_name api.therapytranscriptprocessor.com;

    ssl_certificate /etc/letsencrypt/live/therapytranscriptprocessor.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/therapytranscriptprocessor.com/privkey.pem;
    
    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'none'; connect-src 'self'; frame-ancestors 'none';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Backup and Monitoring

### Database Backup

Create a backup script (`backup.sh`):

```bash
#!/bin/bash
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
BACKUP_DIR="/var/backups/mongodb"
S3_BUCKET="s3://therapy-transcript-processor-backups"

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Get MongoDB connection string from environment
MONGO_URI=$(grep MONGODB_URI /home/ubuntu/therapy-transcript-processor/backend/.env | cut -d '=' -f2)

# Backup MongoDB
mongodump --uri="$MONGO_URI" --archive=$BACKUP_DIR/mongodb_backup_$TIMESTAMP.gz --gzip

# Upload to S3
aws s3 cp $BACKUP_DIR/mongodb_backup_$TIMESTAMP.gz $S3_BUCKET/ --sse AES256

# Keep only the last 7 backups locally
ls -t $BACKUP_DIR/mongodb_backup_*.gz | tail -n +8 | xargs -r rm

# Clean up old backups in S3 (keep last 30)
aws s3 ls $S3_BUCKET/ | sort | head -n -30 | awk '{print $4}' | xargs -I {} aws s3 rm $S3_BUCKET/{}
```

Set up a cron job:
```bash
# Run backup daily at 2 AM
0 2 * * * /home/ubuntu/backup.sh > /var/log/mongodb_backup.log 2>&1
```

### Monitoring Setup

1. **CloudWatch Agent Installation:**
   ```bash
   # Install CloudWatch agent
   wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb
   dpkg -i amazon-cloudwatch-agent.deb

   # Configure CloudWatch agent
   cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << EOF
   {
     "agent": {
       "metrics_collection_interval": 60,
       "run_as_user": "root"
     },
     "metrics": {
       "metrics_collected": {
         "cpu": {
           "resources": [
             "*"
           ],
           "measurement": [
             "cpu_usage_idle",
             "cpu_usage_iowait",
             "cpu_usage_user",
             "cpu_usage_system"
           ],
           "totalcpu": false
         },
         "disk": {
           "resources": [
             "/"
           ],
           "measurement": [
             "used_percent",
             "inodes_free"
           ]
         },
         "diskio": {
           "resources": [
             "*"
           ],
           "measurement": [
             "io_time"
           ]
         },
         "mem": {
           "measurement": [
             "mem_used_percent"
           ]
         },
         "swap": {
           "measurement": [
             "swap_used_percent"
           ]
         }
       },
       "append_dimensions": {
         "InstanceId": "${aws:InstanceId}"
       }
     },
     "logs": {
       "logs_collected": {
         "files": {
           "collect_list": [
             {
               "file_path": "/var/log/syslog",
               "log_group_name": "therapy-transcript-processor-syslog",
               "log_stream_name": "{instance_id}"
             },
             {
               "file_path": "/var/log/nginx/access.log",
               "log_group_name": "therapy-transcript-processor-nginx-access",
               "log_stream_name": "{instance_id}"
             },
             {
               "file_path": "/var/log/nginx/error.log",
               "log_group_name": "therapy-transcript-processor-nginx-error",
               "log_stream_name": "{instance_id}"
             },
             {
               "file_path": "/home/ubuntu/therapy-transcript-processor/logs/*.log",
               "log_group_name": "therapy-transcript-processor-app",
               "log_stream_name": "{instance_id}-{file_basename}"
             }
           ]
         }
       }
     }
   }
   EOF

   # Start CloudWatch agent
   systemctl enable amazon-cloudwatch-agent
   systemctl start amazon-cloudwatch-agent
   ```

2. **CloudWatch Alarms:**
   ```bash
   # Create CPU utilization alarm
   aws cloudwatch put-metric-alarm --alarm-name therapy-transcript-processor-cpu-alarm --alarm-description "Alarm when CPU exceeds 80%" --metric-name CPUUtilization --namespace AWS/EC2 --statistic Average --period 300 --threshold 80 --comparison-operator GreaterThanThreshold --dimensions Name=InstanceId,Value=i-xxxxxxxxxxxxxxxxx --evaluation-periods 2 --alarm-actions arn:aws:sns:us-east-1:123456789012:therapy-transcript-processor-alerts

   # Create disk space alarm
   aws cloudwatch put-metric-alarm --alarm-name therapy-transcript-processor-disk-alarm --alarm-description "Alarm when disk usage exceeds 85%" --metric-name disk_used_percent --namespace CWAgent --statistic Average --period 300 --threshold 85 --comparison-operator GreaterThanThreshold --dimensions Name=InstanceId,Value=i-xxxxxxxxxxxxxxxxx Name=path,Value=/ Name=device,Value=xvda1 Name=fstype,Value=ext4 --evaluation-periods 2 --alarm-actions arn:aws:sns:us-east-1:123456789012:therapy-transcript-processor-alerts

   # Create memory usage alarm
   aws cloudwatch put-metric-alarm --alarm-name therapy-transcript-processor-memory-alarm --alarm-description "Alarm when memory usage exceeds 80%" --metric-name mem_used_percent --namespace CWAgent --statistic Average --period 300 --threshold 80 --comparison-operator GreaterThanThreshold --dimensions Name=InstanceId,Value=i-xxxxxxxxxxxxxxxxx --evaluation-periods 2 --alarm-actions arn:aws:sns:us-east-1:123456789012:therapy-transcript-processor-alerts
   ```

3. **Health Checks:**
   ```bash
   # Create Route 53 health check
   aws route53 create-health-check --caller-reference $(date +%s) --health-check-config '{
     "Port": 443,
     "Type": "HTTPS",
     "ResourcePath": "/health",
     "FullyQualifiedDomainName": "therapytranscriptprocessor.com",
     "RequestInterval": 30,
     "FailureThreshold": 3
   }'
   ```

## Maintenance Procedures

### Regular Updates

1. **System Updates:**
   ```bash
   # Update system packages
   apt-get update
   apt-get upgrade -y
   
   # Reboot if necessary
   if [ -f /var/run/reboot-required ]; then
     reboot
   fi
   ```

2. **Application Updates:**
   ```bash
   # Pull latest code
   cd /home/ubuntu/therapy-transcript-processor
   git pull origin main
   
   # Rebuild and restart containers
   docker-compose down
   docker-compose build
   docker-compose up -d
   ```

3. **SSL Certificate Renewal:**
   ```bash
   # Renew Let's Encrypt certificates
   certbot renew
   ```

### Scaling Procedures

1. **Horizontal Scaling:**
   ```bash
   # Launch additional EC2 instances
   aws ec2 run-instances --image-id ami-xxxxxxxxxxxxxxxxx --count 1 --instance-type t3.medium --key-name your-key-pair --security-group-ids sg-yyyyyyyy --subnet-id subnet-xxxxxxxx --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=therapy-transcript-processor-4}]' --user-data file://ec2-user-data.sh
   
   # Register new instance with target group
   aws elbv2 register-targets --target-group-arn arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/therapy-transcript-processor-tg/xxxxxxxxxxxxxxxx --targets Id=i-aaaaaaaaaaaaaaaaa
   ```

2. **Vertical Scaling:**
   ```bash
   # Stop instance
   aws ec2 stop-instances --instance-ids i-xxxxxxxxxxxxxxxxx
   
   # Change instance type
   aws ec2 modify-instance-attribute --instance-id i-xxxxxxxxxxxxxxxxx --instance-type "{\"Value\": \"t3.large\"}"
   
   # Start instance
   aws ec2 start-instances --instance-ids i-xxxxxxxxxxxxxxxxx
   ```

## Troubleshooting

### Common Issues and Solutions

1. **Application Not Responding:**
   - Check instance status: `aws ec2 describe-instance-status --instance-ids i-xxxxxxxxxxxxxxxxx`
   - Check Docker containers: `docker-compose ps`
   - Check application logs: `docker-compose logs`
   - Restart application: `docker-compose restart`

2. **Database Connection Issues:**
   - Check MongoDB Atlas status
   - Verify network access rules
   - Check connection string in environment variables
   - Restart application: `docker-compose restart backend`

3. **SSL Certificate Issues:**
   - Check certificate status: `aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN`
   - Verify DNS records: `dig therapytranscriptprocessor.com`
   - Renew certificate if expired: `certbot renew`

4. **Load Balancer Issues:**
   - Check target health: `aws elbv2 describe-target-health --target-group-arn arn:aws:elasticloadbalancing:us-east-1:123456789012:targetgroup/therapy-transcript-processor-tg/xxxxxxxxxxxxxxxx`
   - Verify security group rules
   - Check load balancer logs in CloudWatch

## Compliance Documentation

### HIPAA Compliance Checklist

1. **Administrative Safeguards:**
   - Security management process implemented
   - Risk analysis and management conducted
   - Workforce security measures in place
   - Information access management configured
   - Security awareness training provided
   - Contingency plan developed
   - Evaluation mechanisms established
   - Business associate agreements signed

2. **Physical Safeguards:**
   - AWS data centers provide physical safeguards
   - Facility access controls implemented
   - Workstation security measures in place
   - Device and media controls configured

3. **Technical Safeguards:**
   - Access control implemented (authentication, authorization)
   - Audit controls in place (CloudTrail, CloudWatch)
   - Integrity controls configured (checksums, version control)
   - Transmission security implemented (SSL/TLS, encryption)
   - Person or entity authentication enforced (strong passwords, MFA)

4. **Organizational Requirements:**
   - Business associate agreements with AWS and other providers
   - Documentation of security measures
   - Regular security assessments

### Compliance Verification

1. **Regular Audits:**
   - Schedule quarterly security audits
   - Review access logs and user activities
   - Verify encryption settings
   - Test backup and recovery procedures

2. **Penetration Testing:**
   - Conduct annual penetration testing
   - Address identified vulnerabilities
   - Document remediation actions

3. **Documentation Maintenance:**
   - Keep all compliance documentation up to date
   - Document all security incidents and responses
   - Maintain records of all system changes

## Conclusion

This comprehensive deployment guide provides all the necessary steps and configurations to deploy the Therapy Transcript Processor application in a secure, scalable, and HIPAA-compliant production environment. Follow these instructions carefully to ensure a successful deployment and ongoing maintenance of the application.

For any questions or issues, please contact the system administrator or refer to the troubleshooting section of this guide.
