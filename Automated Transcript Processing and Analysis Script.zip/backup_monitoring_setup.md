# Backup and Monitoring Setup for Therapy Transcript Processor

This document outlines the steps for setting up backup and monitoring systems for the Therapy Transcript Processor application in a production environment.

## Database Backup Configuration

### Backup Strategy
- **Frequency:** Daily backups
- **Retention:** Keep the last 7 daily backups
- **Storage:** Encrypted S3 bucket with cross-region replication
- **Method:** Use `mongodump` for logical backups

### Implementation Steps

1.  **Create Backup Script (`backup.sh`):

    ```bash
    #!/bin/bash
    TIMESTAMP=$(date +"%Y%m%d%H%M%S")
    BACKUP_DIR="/var/backups/mongodb"
    S3_BUCKET="s3://your-therapy-processor-backup-bucket"
    MONGO_CONTAINER="therapy-transcript-processor_mongodb_1" # Adjust if container name differs

    # Create backup directory if it doesn't exist
    mkdir -p $BACKUP_DIR

    # Backup MongoDB using mongodump inside the container
    docker exec $MONGO_CONTAINER mongodump --archive --gzip --db therapy-transcript-processor -o /tmp/mongodb_backup_$TIMESTAMP.gz

    # Copy backup from container to host
    docker cp $MONGO_CONTAINER:/tmp/mongodb_backup_$TIMESTAMP.gz $BACKUP_DIR/

    # Remove backup file from container
    docker exec $MONGO_CONTAINER rm /tmp/mongodb_backup_$TIMESTAMP.gz

    # Upload backup to S3 with server-side encryption
    aws s3 cp $BACKUP_DIR/mongodb_backup_$TIMESTAMP.gz $S3_BUCKET/ --sse AES256

    # Remove local backup file after successful upload
    rm $BACKUP_DIR/mongodb_backup_$TIMESTAMP.gz

    # Clean up old backups in S3 (keep last 7)
    aws s3 ls $S3_BUCKET/ | sort | head -n -7 | awk 
    ```

2.  **Make Backup Script Executable:**

    ```bash
    chmod +x backup.sh
    ```

3.  **Set Up Cron Job:**

    ```bash
    # Edit crontab
    crontab -e

    # Add the following line to run the script daily at 2 AM
    0 2 * * * /path/to/your/backup.sh > /var/log/mongodb_backup.log 2>&1
    ```

4.  **Configure S3 Bucket:**
    - Create an S3 bucket (e.g., `your-therapy-processor-backup-bucket`)
    - Enable server-side encryption (SSE-S3 or SSE-KMS)
    - Configure lifecycle policies for object retention/deletion
    - Set up cross-region replication for disaster recovery
    - Ensure appropriate IAM permissions for the EC2 instance role to write to the bucket

## Monitoring Setup

### Monitoring Tools
- **System Metrics:** Prometheus + Node Exporter
- **Application Metrics:** Prometheus + Custom Exporter (if needed) or APM tool
- **Log Aggregation:** ELK Stack (Elasticsearch, Logstash, Kibana) or CloudWatch Logs
- **Visualization:** Grafana or CloudWatch Dashboards
- **Alerting:** Alertmanager or CloudWatch Alarms

### Implementation Steps

1.  **Set Up Prometheus & Grafana:**

    ```bash
    # Run Prometheus container
    docker run -d --name prometheus -p 9090:9090 -v /path/to/prometheus.yml:/etc/prometheus/prometheus.yml prom/prometheus

    # Run Grafana container
    docker run -d --name grafana -p 3000:3000 grafana/grafana
    ```

2.  **Set Up Node Exporter:**

    ```bash
    # Run Node Exporter container
    docker run -d --name node-exporter --pid="host" -v "/:/host:ro,rslave" -p 9100:9100 prom/node-exporter --path.rootfs=/host
    ```

3.  **Configure Prometheus (`prometheus.yml`):**

    ```yaml
    global:
      scrape_interval: 15s

    scrape_configs:
      - job_name: 'node'
        static_configs:
          - targets: ['node-exporter:9100'] # Use container name

      - job_name: 'backend-api'
        # Assuming backend exposes metrics on /metrics endpoint
        static_configs:
          - targets: ['backend:3001'] # Use container name and port
    ```

4.  **Set Up Alertmanager (Optional but Recommended):**

    ```bash
    # Run Alertmanager container
    docker run -d --name alertmanager -p 9093:9093 prom/alertmanager
    ```
    - Configure Prometheus to send alerts to Alertmanager.
    - Configure Alertmanager routing and notification channels (e.g., Slack, PagerDuty, Email).

5.  **Set Up Log Aggregation (Example with CloudWatch Agent):**
    - Install CloudWatch Agent on the EC2 instance.
    - Configure the agent to collect system logs (`/var/log/syslog`, `/var/log/auth.log`) and application logs (Docker container logs or file logs).
    - Create CloudWatch Log Groups and Streams.
    - Set up Metric Filters and CloudWatch Alarms based on log patterns (e.g., error counts).

6.  **Create Monitoring Dashboards (Grafana or CloudWatch):**
    - **System Metrics:** CPU, Memory, Disk I/O, Network Traffic.
    - **Application Metrics:** Request Latency, Error Rates, Throughput, Database Connection Pool Usage.
    - **Log Insights:** Error trends, specific event occurrences.

7.  **Configure CloudWatch Alarms:**
    - **High CPU/Memory Utilization:** Trigger alerts if resources exceed thresholds.
    - **Low Disk Space:** Alert before disk space runs out.
    - **High Error Rate:** Monitor application error logs or metrics.
    - **Unhealthy Host Count (Load Balancer):** Alert if instances become unhealthy.
    - **Database Connection Issues:** Monitor database performance metrics.
    - **SSL Certificate Expiry:** Set alarms for certificate renewal reminders.

## Verification

1.  **Backup Verification:**
    - Manually run the backup script and verify the `.gz` file is created locally and uploaded to S3.
    - Periodically restore a backup to a test environment to ensure integrity.
    - Check cron job logs (`/var/log/mongodb_backup.log`) for errors.

2.  **Monitoring Verification:**
    - Access Grafana/CloudWatch dashboards and verify data is being collected.
    - Check Prometheus targets page (`http://<prometheus-ip>:9090/targets`) to ensure services are being scraped.
    - Trigger test alerts to verify notification channels are working.
    - Review CloudWatch Logs for application and system events.

## Maintenance

- Regularly review and update backup retention policies.
- Test disaster recovery procedures annually.
- Update monitoring dashboards and alert rules as the application evolves.
- Keep monitoring tools (Prometheus, Grafana, CloudWatch Agent) updated.
