import { Router } from 'express';
import userController from '../controllers/userController';
import { auth, authorize } from '../middleware/auth';

const router = Router();

// Public routes
router.post('/register', userController.register);
router.post('/login', userController.login);

// Protected routes
router.get('/profile', auth, userController.getProfile);
router.post('/api-keys', auth, userController.saveApiKeys);
router.delete('/api-keys', auth, userController.deleteApiKeys);

export default router;
