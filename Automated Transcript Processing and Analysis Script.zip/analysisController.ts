import { Request, Response } from 'express';
import aiProcessingService from '../services/aiProcessingService';
import Analysis from '../models/Analysis';

/**
 * Controller for handling analysis operations
 */
class AnalysisController {
  /**
   * Create a new analysis for a transcript
   */
  async createAnalysis(req: Request, res: Response) {
    try {
      const { transcriptId, provider, model } = req.body;
      const user = req.user!;
      
      if (!transcriptId || !provider || !model) {
        return res.status(400).json({ message: 'Missing required fields' });
      }
      
      // Validate provider
      if (provider !== 'openai' && provider !== 'anthropic') {
        return res.status(400).json({ message: 'Invalid provider' });
      }
      
      // Start processing
      const analysisId = await aiProcessingService.processTranscript(
        user._id.toString(),
        transcriptId,
        provider,
        model
      );
      
      res.status(201).json({
        message: 'Analysis started successfully',
        analysisId
      });
    } catch (error: any) {
      console.error('Create analysis error:', error);
      res.status(500).json({ message: error.message || 'Server error creating analysis' });
    }
  }
  
  /**
   * Get analysis by ID
   */
  async getAnalysis(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      
      const analysis = await aiProcessingService.getAnalysis(user._id.toString(), id);
      
      if (!analysis) {
        return res.status(404).json({ message: 'Analysis not found' });
      }
      
      res.status(200).json({ analysis });
    } catch (error) {
      console.error('Get analysis error:', error);
      res.status(500).json({ message: 'Server error retrieving analysis' });
    }
  }
  
  /**
   * Get all analyses for a transcript
   */
  async getAnalysesForTranscript(req: Request, res: Response) {
    try {
      const { transcriptId } = req.params;
      const user = req.user!;
      
      const analyses = await aiProcessingService.getAnalysesForTranscript(
        user._id.toString(),
        transcriptId
      );
      
      res.status(200).json({ analyses });
    } catch (error) {
      console.error('Get analyses error:', error);
      res.status(500).json({ message: 'Server error retrieving analyses' });
    }
  }
  
  /**
   * Delete analysis
   */
  async deleteAnalysis(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      
      // Find analysis
      const analysis = await Analysis.findOne({
        _id: id,
        userId: user._id
      });
      
      if (!analysis) {
        return res.status(404).json({ message: 'Analysis not found' });
      }
      
      // Delete analysis
      await Analysis.deleteOne({ _id: id });
      
      res.status(200).json({ message: 'Analysis deleted successfully' });
    } catch (error) {
      console.error('Delete analysis error:', error);
      res.status(500).json({ message: 'Server error deleting analysis' });
    }
  }
}

export default new AnalysisController();
