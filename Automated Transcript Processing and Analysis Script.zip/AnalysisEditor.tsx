import React from 'react';

interface AnalysisEditorProps {
  analysis: any;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onContentUpdate: (section: string, content: string) => void;
}

const AnalysisEditor: React.FC<AnalysisEditorProps> = ({
  analysis,
  activeSection,
  onSectionChange,
  onContentUpdate
}) => {
  // Get content for the active section
  const getContent = () => {
    if (activeSection.includes('.')) {
      // Handle nested properties like supplementalAnalyses.keyPoints
      const [parent, child] = activeSection.split('.');
      return analysis[parent][child];
    } else {
      // Handle top-level properties
      return analysis[activeSection];
    }
  };

  // Handle content changes
  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onContentUpdate(activeSection, e.target.value);
  };

  return (
    <div className="analysis-editor">
      <div className="editor-sidebar">
        <div className="section-group">
          <h3>SOAP Note</h3>
          <ul>
            <li 
              className={activeSection === 'soapNote.subjective' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.subjective')}
            >
              Subjective
            </li>
            <li 
              className={activeSection === 'soapNote.objective' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.objective')}
            >
              Objective
            </li>
            <li 
              className={activeSection === 'soapNote.assessment' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.assessment')}
            >
              Assessment
            </li>
            <li 
              className={activeSection === 'soapNote.plan' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.plan')}
            >
              Plan
            </li>
          </ul>
        </div>
        
        <div className="section-group">
          <h3>Supplemental Analyses</h3>
          <ul>
            <li 
              className={activeSection === 'supplementalAnalyses.keyPoints' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.keyPoints')}
            >
              Key Points
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.significantQuotes' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.significantQuotes')}
            >
              Significant Quotes
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.tonalAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.tonalAnalysis')}
            >
              Tonal Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.thematicAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.thematicAnalysis')}
            >
              Thematic Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.sentimentAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.sentimentAnalysis')}
            >
              Sentiment Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.narrativeSummary' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.narrativeSummary')}
            >
              Narrative Summary
            </li>
          </ul>
        </div>
      </div>
      
      <div className="editor-content">
        <div className="editor-header">
          <h2>{activeSection.includes('.') ? activeSection.split('.')[1] : activeSection}</h2>
        </div>
        
        <div className="editor-textarea-container">
          <textarea
            className="editor-textarea"
            value={getContent()}
            onChange={handleContentChange}
            placeholder="Content will appear here..."
          />
        </div>
      </div>
    </div>
  );
};

export default AnalysisEditor;
