import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  hasOpenAiKey: boolean;
  hasAnthropicKey: boolean;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateApiKeys: (keys: { openAiKey: string | null; anthropicKey: string | null }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('token');
        if (token) {
          // For demo purposes, create a mock user
          setUser({
            id: '1',
            firstName: 'Demo',
            lastName: 'User',
            email: 'demo@example.com',
            role: 'therapist',
            hasOpenAiKey: true,
            hasAnthropicKey: true,
            createdAt: new Date().toISOString()
          });
        }
      } catch (error) {
        console.error('Authentication check failed:', error);
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // For demo purposes, simulate a successful login
      if (email === 'demo@example.com' && password === 'password') {
        const mockToken = 'mock-jwt-token';
        localStorage.setItem('token', mockToken);
        
        setUser({
          id: '1',
          firstName: 'Demo',
          lastName: 'User',
          email: 'demo@example.com',
          role: 'therapist',
          hasOpenAiKey: true,
          hasAnthropicKey: true,
          createdAt: new Date().toISOString()
        });
        
        return;
      }
      
      throw new Error('Invalid credentials');
    } catch (error) {
      throw error;
    }
  };

  const register = async (email: string, password: string) => {
    try {
      // For demo purposes, simulate a successful registration
      const mockToken = 'mock-jwt-token';
      localStorage.setItem('token', mockToken);
      
      setUser({
        id: '1',
        firstName: 'New',
        lastName: 'User',
        email: email,
        role: 'therapist',
        hasOpenAiKey: false,
        hasAnthropicKey: false,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const updateApiKeys = async (keys: { openAiKey: string | null; anthropicKey: string | null }) => {
    try {
      // For demo purposes, simulate updating API keys
      setUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          hasOpenAiKey: !!keys.openAiKey || prev.hasOpenAiKey,
          hasAnthropicKey: !!keys.anthropicKey || prev.hasAnthropicKey
        };
      });
    } catch (error) {
      throw error;
    }
  };

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    updateApiKeys
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
