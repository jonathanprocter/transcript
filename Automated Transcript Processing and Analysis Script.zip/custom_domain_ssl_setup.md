# Custom Domain and SSL Setup for Therapy Transcript Processor

This document outlines the steps for registering a custom domain, configuring DNS settings, and setting up SSL certificates for the Therapy Transcript Processor application.

## Domain Registration

1. Register the domain "therapytranscriptprocessor.com" through AWS Route 53:

```bash
# Using AWS CLI
aws route53domains register-domain --domain-name therapytranscriptprocessor.com --duration-in-years 1 --auto-renew --admin-contact ... --registrant-contact ... --tech-contact ...
```

Alternatively, register through the AWS Management Console:
- Navigate to Route 53 service
- Select "Registered domains" from the left navigation
- Click "Register Domain"
- Follow the prompts to register "therapytranscriptprocessor.com"

## DNS Configuration

Create the following DNS records in Route 53:

1. Create a hosted zone for the domain:

```bash
# Using AWS CLI
aws route53 create-hosted-zone --name therapytranscriptprocessor.com --caller-reference $(date +%s)
```

2. Configure DNS records:

```bash
# Create record sets for main domain and www subdomain
aws route53 change-resource-record-sets --hosted-zone-id YOUR_HOSTED_ZONE_ID --change-batch '{
  "Changes": [
    {
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "therapytranscriptprocessor.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
          "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
          "EvaluateTargetHealth": true
        }
      }
    },
    {
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "www.therapytranscriptprocessor.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
          "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
          "EvaluateTargetHealth": true
        }
      }
    },
    {
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "api.therapytranscriptprocessor.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "YOUR_LOAD_BALANCER_HOSTED_ZONE_ID",
          "DNSName": "YOUR_LOAD_BALANCER_DNS_NAME",
          "EvaluateTargetHealth": true
        }
      }
    }
  ]
}'
```

## SSL Certificate Setup

1. Request an SSL certificate through AWS Certificate Manager (ACM):

```bash
# Using AWS CLI
aws acm request-certificate \
  --domain-name therapytranscriptprocessor.com \
  --validation-method DNS \
  --subject-alternative-names www.therapytranscriptprocessor.com api.therapytranscriptprocessor.com \
  --idempotency-token $(date +%s)
```

2. Create DNS validation records:

```bash
# Get certificate details
aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN

# Create validation records in Route 53
aws route53 change-resource-record-sets --hosted-zone-id YOUR_HOSTED_ZONE_ID --change-batch '{
  "Changes": [
    {
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "VALIDATION_CNAME_NAME",
        "Type": "CNAME",
        "TTL": 300,
        "ResourceRecords": [
          {
            "Value": "VALIDATION_CNAME_VALUE"
          }
        ]
      }
    }
  ]
}'
```

3. Wait for certificate validation:

```bash
# Check validation status
aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN
```

## Load Balancer Configuration

1. Create a security group for the load balancer:

```bash
# Create security group
aws ec2 create-security-group \
  --group-name therapy-transcript-processor-lb-sg \
  --description "Security group for Therapy Transcript Processor load balancer" \
  --vpc-id YOUR_VPC_ID

# Add inbound rules
aws ec2 authorize-security-group-ingress \
  --group-id YOUR_SECURITY_GROUP_ID \
  --protocol tcp \
  --port 80 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id YOUR_SECURITY_GROUP_ID \
  --protocol tcp \
  --port 443 \
  --cidr 0.0.0.0/0
```

2. Create an Application Load Balancer:

```bash
# Create load balancer
aws elbv2 create-load-balancer \
  --name therapy-transcript-processor-lb \
  --subnets YOUR_SUBNET_ID_1 YOUR_SUBNET_ID_2 \
  --security-groups YOUR_SECURITY_GROUP_ID \
  --scheme internet-facing \
  --type application

# Create target group
aws elbv2 create-target-group \
  --name therapy-transcript-processor-tg \
  --protocol HTTP \
  --port 3000 \
  --vpc-id YOUR_VPC_ID \
  --health-check-path / \
  --health-check-protocol HTTP

# Register targets
aws elbv2 register-targets \
  --target-group-arn YOUR_TARGET_GROUP_ARN \
  --targets Id=YOUR_INSTANCE_ID

# Create HTTPS listener
aws elbv2 create-listener \
  --load-balancer-arn YOUR_LOAD_BALANCER_ARN \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=YOUR_CERTIFICATE_ARN \
  --default-actions Type=forward,TargetGroupArn=YOUR_TARGET_GROUP_ARN

# Create HTTP listener with redirect to HTTPS
aws elbv2 create-listener \
  --load-balancer-arn YOUR_LOAD_BALANCER_ARN \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=redirect,RedirectConfig="{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}"
```

## Security Configuration

1. Configure security headers in the load balancer:

```bash
# Create custom response policy
aws elbv2 create-trust-store \
  --name therapy-transcript-processor-security-headers \
  --trust-store-data '{
    "Version": "1.0.0",
    "TrustStoreRevocationList": []
  }'

# Update listener with security headers
aws elbv2 modify-listener \
  --listener-arn YOUR_LISTENER_ARN \
  --default-actions Type=fixed-response,FixedResponseConfig="{StatusCode=200,ContentType=text/plain,MessageBody=OK}" \
  --ssl-policy ELBSecurityPolicy-TLS-1-2-2017-01
```

2. Configure CORS for API endpoints:

```bash
# Update API Gateway CORS configuration
aws apigateway update-resource \
  --rest-api-id YOUR_API_ID \
  --resource-id YOUR_RESOURCE_ID \
  --patch-operations op=replace,path=/corsConfiguration,value='{
    "allowOrigins": ["https://therapytranscriptprocessor.com", "https://www.therapytranscriptprocessor.com"],
    "allowMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    "allowHeaders": ["Content-Type", "Authorization"],
    "exposeHeaders": ["Content-Length", "X-Request-Id"],
    "maxAge": 3600,
    "allowCredentials": true
  }'
```

## DNS Propagation Verification

1. Verify DNS propagation:

```bash
# Check DNS propagation
dig therapytranscriptprocessor.com
dig www.therapytranscriptprocessor.com
dig api.therapytranscriptprocessor.com
```

2. Verify SSL certificate:

```bash
# Check SSL certificate
openssl s_client -connect therapytranscriptprocessor.com:443 -servername therapytranscriptprocessor.com
```

## Monitoring Setup

1. Configure Route 53 health checks:

```bash
# Create health check
aws route53 create-health-check \
  --caller-reference $(date +%s) \
  --health-check-config '{
    "Port": 443,
    "Type": "HTTPS",
    "ResourcePath": "/health",
    "FullyQualifiedDomainName": "therapytranscriptprocessor.com",
    "RequestInterval": 30,
    "FailureThreshold": 3
  }'
```

2. Set up CloudWatch alarms for domain monitoring:

```bash
# Create CloudWatch alarm
aws cloudwatch put-metric-alarm \
  --alarm-name TherapyTranscriptProcessor-DomainHealth \
  --alarm-description "Alarm when the domain is unhealthy" \
  --metric-name HealthCheckStatus \
  --namespace AWS/Route53 \
  --statistic Minimum \
  --period 60 \
  --threshold 1 \
  --comparison-operator LessThanThreshold \
  --dimensions Name=HealthCheckId,Value=YOUR_HEALTH_CHECK_ID \
  --evaluation-periods 1 \
  --alarm-actions YOUR_SNS_TOPIC_ARN
```

## Maintenance Procedures

1. SSL certificate renewal:

AWS Certificate Manager automatically renews certificates, but verify the renewal status:

```bash
# Check certificate status
aws acm describe-certificate --certificate-arn YOUR_CERTIFICATE_ARN
```

2. Domain renewal:

```bash
# Enable auto-renewal
aws route53domains update-domain-contact --domain-name therapytranscriptprocessor.com --admin-privacy --registrant-privacy --tech-privacy
```

3. Regular DNS checks:

```bash
# Schedule regular DNS checks
echo "0 0 * * * dig therapytranscriptprocessor.com > /var/log/dns-checks.log" | crontab -
```

## Troubleshooting

1. DNS issues:
   - Check Route 53 hosted zone configuration
   - Verify nameserver delegation
   - Check for conflicting DNS records

2. SSL certificate issues:
   - Verify certificate validation status in ACM
   - Check certificate association with load balancer
   - Verify certificate covers all required domains

3. Load balancer issues:
   - Check target group health
   - Verify security group configurations
   - Check listener rules and routing
