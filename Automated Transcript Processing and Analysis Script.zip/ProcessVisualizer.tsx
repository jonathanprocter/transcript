import React from 'react';

interface ProcessVisualizerProps {
  steps: {
    id: string;
    name: string;
    description: string;
    status: 'pending' | 'in-progress' | 'completed' | 'failed';
    progress?: number;
  }[];
  currentStep: string;
}

const ProcessVisualizer: React.FC<ProcessVisualizerProps> = ({
  steps,
  currentStep
}) => {
  return (
    <div className="process-visualizer">
      <div className="process-timeline">
        {steps.map((step, index) => (
          <div 
            key={step.id} 
            className={`timeline-step ${step.status} ${step.id === currentStep ? 'current' : ''}`}
          >
            <div className="timeline-connector">
              {index > 0 && <div className="connector-line"></div>}
              <div className="connector-dot"></div>
            </div>
            <div className="timeline-content">
              <h4 className="step-name">{step.name}</h4>
              <p className="step-description">{step.description}</p>
              
              {step.status === 'in-progress' && step.progress !== undefined && (
                <div className="step-progress">
                  <div className="progress-track">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${step.progress}%` }}
                    ></div>
                  </div>
                  <span className="progress-percentage">{step.progress}%</span>
                </div>
              )}
              
              {step.status === 'failed' && (
                <div className="step-error">
                  <span className="error-icon">⚠️</span>
                  <span className="error-text">Failed</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProcessVisualizer;
