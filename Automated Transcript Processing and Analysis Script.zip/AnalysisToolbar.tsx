import React from 'react';

interface AnalysisToolbarProps {
  viewMode: 'edit' | 'split' | 'preview';
  onViewModeChange: (mode: 'edit' | 'split' | 'preview') => void;
  onSave: () => void;
  onExport: () => void;
  saving: boolean;
  saveSuccess: boolean;
}

const AnalysisToolbar: React.FC<AnalysisToolbarProps> = ({
  viewMode,
  onViewModeChange,
  onSave,
  onExport,
  saving,
  saveSuccess
}) => {
  return (
    <div className="analysis-toolbar">
      <div className="view-mode-selector">
        <button 
          className={`view-mode-button ${viewMode === 'edit' ? 'active' : ''}`}
          onClick={() => onViewModeChange('edit')}
        >
          Edit Mode
        </button>
        <button 
          className={`view-mode-button ${viewMode === 'split' ? 'active' : ''}`}
          onClick={() => onViewModeChange('split')}
        >
          Split View
        </button>
        <button 
          className={`view-mode-button ${viewMode === 'preview' ? 'active' : ''}`}
          onClick={() => onViewModeChange('preview')}
        >
          Preview
        </button>
      </div>
      
      <div className="action-buttons">
        <button 
          className="save-button"
          onClick={onSave}
          disabled={saving}
        >
          {saving ? 'Saving...' : 'Save Changes'}
        </button>
        <button 
          className="export-button"
          onClick={onExport}
        >
          Export
        </button>
      </div>
      
      {saveSuccess && (
        <div className="save-success-message">
          Changes saved successfully!
        </div>
      )}
    </div>
  );
};

export default AnalysisToolbar;
