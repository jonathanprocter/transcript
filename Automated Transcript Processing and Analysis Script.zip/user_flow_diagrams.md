# Therapy Transcript Processor Web Application
# User Flow Diagrams

## 1. Overview of User Flows

This document outlines the key user flows within the Therapy Transcript Processor application, providing a clear visualization of how users will navigate through the system to accomplish various tasks. Each flow represents a complete user journey from initiation to completion of a specific goal.

## 2. User Onboarding Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Landing Page   │────▶│  Registration   │────▶│  API Setup      │────▶│  Tutorial       │
│                 │     │                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        │
                                                        ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Dashboard      │◀────│  Preferences    │◀────│  Template       │
│                 │     │  Setup          │     │  Selection      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

### 2.1 Detailed Steps

1. **Landing Page**
   - User visits application website
   - Views product information and benefits
   - Clicks "Sign Up" or "Log In"

2. **Registration**
   - User enters professional credentials
   - Creates account with email and password
   - Verifies email address
   - Accepts terms of service and privacy policy

3. **API Setup**
   - User enters OpenAI and/or Anthropic API keys
   - Selects preferred API provider
   - Tests API connection
   - Receives confirmation of successful setup

4. **Tutorial**
   - User is guided through application features
   - Views sample transcript processing demonstration
   - Can skip tutorial or continue step-by-step
   - Marks tutorial completion

5. **Template Selection**
   - User selects default note template
   - Customizes template if desired
   - Previews template format
   - Saves template preferences

6. **Preferences Setup**
   - User configures default settings
   - Sets privacy and security preferences
   - Configures export defaults
   - Saves all preferences

7. **Dashboard**
   - User arrives at main dashboard
   - Views welcome message and quick start guide
   - Sees empty state with suggested first actions
   - Ready to begin using the application

## 3. Transcript Upload and Processing Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Dashboard      │────▶│  Upload         │────▶│  PDF Preview    │────▶│  Client/Session │
│                 │     │  Interface      │     │  & Validation   │     │  Details        │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        │
                                                        ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Results        │◀────│  Processing     │◀────│  Processing     │◀────│  Configuration  │
│  Viewer         │     │  Complete       │     │  Status         │     │  Options        │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
```

### 3.1 Detailed Steps

1. **Dashboard**
   - User navigates to dashboard
   - Clicks "Upload New Transcript" button
   - Selects "Process New Session" from actions menu

2. **Upload Interface**
   - User sees drag-and-drop area and file browser button
   - Uploads PDF transcript file
   - System validates file format and size
   - Shows upload progress indicator

3. **PDF Preview & Validation**
   - System displays preview of uploaded PDF
   - Performs initial OCR and text extraction
   - Shows quality assessment results
   - Allows user to confirm or reject extraction results

4. **Client/Session Details**
   - User enters or selects client name
   - Inputs session date and time
   - Adds any session tags or categories
   - Provides additional context if needed

5. **Configuration Options**
   - User selects processing depth
   - Chooses which analyses to include
   - Sets API preferences (if different from defaults)
   - Configures privacy settings for this transcript

6. **Processing Status**
   - System shows processing pipeline visualization
   - Displays progress for each component
   - Shows estimated completion time
   - Provides option to cancel or pause processing

7. **Processing Complete**
   - System notifies user of completed processing
   - Shows summary of generated components
   - Provides quality assessment of results
   - Offers options to view, edit, or export results

8. **Results Viewer**
   - User views complete progress note
   - Can navigate between sections
   - Sees side-by-side view of transcript and analysis
   - Has options to edit, save, or export

## 4. Results Viewing and Exploration Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Results        │────▶│  Section        │────▶│  Edit Mode      │
│  Overview       │     │  Navigation     │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
       │                        │                       │
       │                        │                       │
       ▼                        ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Side-by-Side   │     │  Visualization  │     │  Save Version   │
│  Comparison     │     │  View           │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
       │                        │                       │
       │                        │                       │
       ▼                        ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Export         │     │  Share          │     │  Progress Note  │
│  Options        │     │  Options        │     │  Library        │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

### 4.1 Detailed Steps

1. **Results Overview**
   - User views complete progress note
   - Sees summary of all generated sections
   - Can collapse/expand individual sections
   - Views quality indicators for each section

2. **Section Navigation**
   - User navigates between SOAP components
   - Explores supplemental analyses
   - Jumps to specific sections via navigation menu
   - Uses search to find specific content

3. **Edit Mode**
   - User enables editing for any section
   - Makes modifications to AI-generated content
   - Adds therapist notes or annotations
   - Receives real-time feedback on changes

4. **Side-by-Side Comparison**
   - User toggles split-view mode
   - Sees transcript and analysis side-by-side
   - Can highlight sections in transcript to see corresponding analysis
   - Navigates both documents synchronously

5. **Visualization View**
   - User accesses visual representations of analyses
   - Views tonal shift timeline
   - Explores thematic analysis visualization
   - Interacts with sentiment analysis charts

6. **Save Version**
   - User saves edited version
   - Adds version notes or comments
   - Sets version as primary if desired
   - Returns to viewing mode

7. **Export Options**
   - User selects export format (.docx, .pdf, .txt, .html)
   - Configures export settings
   - Previews export result
   - Completes export to local device

8. **Share Options**
   - User configures sharing permissions
   - Generates secure sharing link
   - Sets expiration for shared access
   - Tracks access to shared content

9. **Progress Note Library**
   - User saves note to library
   - Organizes note within client records
   - Tags note with relevant categories
   - Returns to dashboard or starts new processing

## 5. Progress Note Library Interaction Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Dashboard      │────▶│  Progress Note  │────▶│  Filtering &    │────▶│  Note Details   │
│                 │     │  Library        │     │  Searching      │     │  View           │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                               │                                                │
                               │                                                │
                               ▼                                                ▼
                        ┌─────────────────┐                             ┌─────────────────┐
                        │                 │                             │                 │
                        │  Client         │                             │  Version        │
                        │  Grouping       │                             │  History        │
                        └─────────────────┘                             └─────────────────┘
                               │                                                │
                               │                                                │
                               ▼                                                ▼
                        ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │     │                 │
                        │  Timeline       │────▶│  Comparison     │◀────│  Edit           │
                        │  View           │     │  View           │     │  Note           │
                        └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        │
                                                        ▼
                                                ┌─────────────────┐
                                                │                 │
                                                │  Batch          │
                                                │  Actions        │
                                                └─────────────────┘
```

### 5.1 Detailed Steps

1. **Dashboard**
   - User navigates to dashboard
   - Clicks "Progress Note Library" button
   - Views recent notes summary

2. **Progress Note Library**
   - User sees list/grid of all progress notes
   - Views organization by client, date, or tags
   - Sees status indicators for each note
   - Can select multiple notes for batch actions

3. **Filtering & Searching**
   - User filters notes by various criteria
   - Searches for specific content
   - Applies date range filters
   - Filters by processing status or quality

4. **Client Grouping**
   - User views notes grouped by client
   - Sees client summary statistics
   - Navigates between client groups
   - Manages client information

5. **Timeline View**
   - User views chronological representation of sessions
   - Sees progression of themes or topics
   - Identifies patterns across sessions
   - Navigates to specific time periods

6. **Note Details View**
   - User views complete details of selected note
   - Sees all SOAP components and supplemental analyses
   - Views metadata and processing information
   - Has options to edit, export, or share

7. **Version History**
   - User accesses version history of note
   - Compares different versions
   - Restores previous versions if needed
   - Views edit history and comments

8. **Edit Note**
   - User makes changes to existing note
   - Adds therapist annotations
   - Updates client information
   - Saves new version

9. **Comparison View**
   - User compares multiple sessions
   - Views side-by-side comparison of notes
   - Identifies changes or progress
   - Generates comparison report

10. **Batch Actions**
    - User selects multiple notes
    - Performs batch export
    - Applies tags or categories to multiple notes
    - Generates summary reports across sessions

## 6. Export and Sharing Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Results Viewer │────▶│  Export         │────▶│  Format         │────▶│  Template       │
│  or Library     │     │  Interface      │     │  Selection      │     │  Customization  │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                                                │
                                                                                │
                                                                                ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │     │                 │
│  Confirmation   │◀────│  Export         │◀────│  PII Review     │◀────│  Preview        │
│  & Download     │     │  Processing     │     │  & Redaction    │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
       │
       │
       ▼
┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │
│  Share          │────▶│  Permission     │
│  Options        │     │  Settings       │
└─────────────────┘     └─────────────────┘
                                │
                                │
                                ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │
                        │  Link           │────▶│  Access         │
                        │  Generation     │     │  Tracking       │
                        └─────────────────┘     └─────────────────┘
```

### 6.1 Detailed Steps

1. **Results Viewer or Library**
   - User views completed progress note
   - Selects "Export" or "Share" option
   - Can initiate from individual note or batch selection

2. **Export Interface**
   - User sees export options dashboard
   - Views previously used export configurations
   - Selects single or batch export
   - Configures export settings

3. **Format Selection**
   - User selects output format (.docx, .pdf, .txt, .html)
   - Configures format-specific options
   - Sets quality and compression settings for PDFs
   - Chooses compatibility options for different systems

4. **Template Customization**
   - User selects document template
   - Customizes header, footer, and branding
   - Configures section inclusion/exclusion
   - Sets formatting preferences

5. **Preview**
   - User views preview of export result
   - Verifies formatting and content
   - Makes adjustments if needed
   - Approves preview to continue

6. **PII Review & Redaction**
   - System highlights potential personal identifiers
   - User reviews automated PII detection
   - Configures redaction settings
   - Approves or modifies redactions

7. **Export Processing**
   - System generates export files
   - Shows progress indicator
   - Performs any necessary conversions
   - Prepares download package

8. **Confirmation & Download**
   - User receives confirmation of successful export
   - Downloads files to local device
   - Views export summary
   - Can proceed to sharing if desired

9. **Share Options**
   - User selects sharing method
   - Configures sharing settings
   - Sets expiration and access limits
   - Reviews sharing permissions

10. **Permission Settings**
    - User configures who can access shared content
    - Sets view-only or edit permissions
    - Configures download restrictions
    - Sets notification preferences

11. **Link Generation**
    - System generates secure sharing link
    - Shows link and copy option
    - Provides QR code alternative
    - Confirms link creation

12. **Access Tracking**
    - User views access logs for shared content
    - Sees when and who accessed shared notes
    - Can revoke access if needed
    - Receives notifications of access events

## 7. Account and Settings Management Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Dashboard      │────▶│  Account        │────▶│  Profile        │
│                 │     │  Settings       │     │  Management     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │                        │
                               │                        │
                               ▼                        ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │
                        │  API Key        │     │  Security       │
                        │  Management     │     │  Settings       │
                        └─────────────────┘     └─────────────────┘
                               │                        │
                               │                        │
                               ▼                        ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │
                        │  Template       │     │  Privacy        │
                        │  Management     │     │  Settings       │
                        └─────────────────┘     └─────────────────┘
                               │                        │
                               │                        │
                               ▼                        ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │                 │     │                 │
                        │  Notification   │     │  Billing &      │
                        │  Preferences    │     │  Usage          │
                        └─────────────────┘     └─────────────────┘
```

### 7.1 Detailed Steps

1. **Dashboard**
   - User navigates to dashboard
   - Clicks account or settings icon
   - Selects settings category

2. **Account Settings**
   - User views account overview
   - Sees subscription status
   - Accesses various settings categories
   - Views account activity summary

3. **Profile Management**
   - User updates personal information
   - Manages professional credentials
   - Updates contact information
   - Configures account recovery options

4. **API Key Management**
   - User views current API keys
   - Updates OpenAI or Anthropic keys
   - Monitors API usage and costs
   - Sets usage limits and alerts

5. **Security Settings**
   - User changes password
   - Configures two-factor authentication
   - Views login history
   - Sets session timeout preferences

6. **Template Management**
   - User creates and edits note templates
   - Sets default templates
   - Imports/exports templates
   - Previews template formats

7. **Privacy Settings**
   - User configures data retention policies
   - Sets default PII handling preferences
   - Configures data processing location
   - Reviews privacy policy and consents

8. **Notification Preferences**
   - User sets email notification preferences
   - Configures in-app notifications
   - Sets alert thresholds
   - Manages communication preferences

9. **Billing & Usage**
   - User views subscription details
   - Monitors API usage and costs
   - Updates payment information
   - Views invoices and receipts

## 8. Conclusion

These user flow diagrams provide a comprehensive visualization of the key interaction paths within the Therapy Transcript Processor application. They serve as a blueprint for development, ensuring that all user journeys are intuitive, efficient, and aligned with the needs of mental health professionals.

The flows are designed to support a seamless experience from onboarding through transcript processing to results management, with careful attention to the specific requirements of clinical documentation workflows. Each flow incorporates appropriate security and privacy considerations, reflecting the sensitive nature of the data being processed.

These diagrams should be used in conjunction with the detailed design specifications to guide the implementation of the application's user interface and interaction design.
