# Production Deployment Configuration

This document outlines the specific configuration steps for deploying the Therapy Transcript Processor application to a production environment.

## AWS Deployment Configuration

### EC2 Instance Setup
```bash
# Launch EC2 instance with Ubuntu 22.04 LTS
# t3.medium recommended for production workloads

# Update system packages
sudo apt update
sudo apt upgrade -y

# Install required dependencies
sudo apt install -y nginx certbot python3-certbot-nginx docker.io docker-compose git

# Enable and start Docker
sudo systemctl enable docker
sudo systemctl start docker

# Add current user to docker group
sudo usermod -aG docker ${USER}
```

### Application Deployment

```bash
# Clone application repository
git clone https://github.com/your-org/therapy-transcript-processor.git
cd therapy-transcript-processor

# Create environment file
cat > .env << EOF
NODE_ENV=production
PORT=3000
MONGODB_URI=mongodb://mongodb:27017/therapy-transcript-processor
JWT_SECRET=your-secure-jwt-secret
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
ENCRYPTION_KEY=your-secure-encryption-key
EOF

# Create docker-compose.yml
cat > docker-compose.yml << EOF
version: '3'

services:
  mongodb:
    image: mongo:latest
    volumes:
      - mongodb_data:/data/db
    restart: always
    networks:
      - app-network

  backend:
    build: ./backend
    restart: always
    depends_on:
      - mongodb
    env_file:
      - .env
    networks:
      - app-network

  frontend:
    build: ./frontend
    restart: always
    depends_on:
      - backend
    networks:
      - app-network

networks:
  app-network:
    driver: bridge

volumes:
  mongodb_data:
EOF

# Build and start the application
docker-compose up -d
```

### Nginx Configuration

```bash
# Create Nginx configuration
sudo cat > /etc/nginx/sites-available/therapy-transcript-processor << EOF
server {
    listen 80;
    server_name therapytranscriptprocessor.com www.therapytranscriptprocessor.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable the site
sudo ln -s /etc/nginx/sites-available/therapy-transcript-processor /etc/nginx/sites-enabled/

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Set up SSL with Let's Encrypt
sudo certbot --nginx -d therapytranscriptprocessor.com -d www.therapytranscriptprocessor.com
```

## Database Backup Configuration

```bash
# Create backup script
cat > backup.sh << EOF
#!/bin/bash
TIMESTAMP=\$(date +"%Y%m%d%H%M%S")
BACKUP_DIR="/var/backups/mongodb"

# Create backup directory if it doesn't exist
mkdir -p \$BACKUP_DIR

# Backup MongoDB
docker exec -it therapy-transcript-processor_mongodb_1 mongodump --out /dump

# Copy backup from container
docker cp therapy-transcript-processor_mongodb_1:/dump \$BACKUP_DIR/dump_\$TIMESTAMP

# Compress backup
tar -zcvf \$BACKUP_DIR/mongodb_backup_\$TIMESTAMP.tar.gz \$BACKUP_DIR/dump_\$TIMESTAMP

# Remove uncompressed backup
rm -rf \$BACKUP_DIR/dump_\$TIMESTAMP

# Keep only the last 7 backups
ls -t \$BACKUP_DIR/mongodb_backup_*.tar.gz | tail -n +8 | xargs -r rm

# Upload to S3 (if configured)
# aws s3 cp \$BACKUP_DIR/mongodb_backup_\$TIMESTAMP.tar.gz s3://your-backup-bucket/
EOF

# Make backup script executable
chmod +x backup.sh

# Set up cron job for daily backups
(crontab -l 2>/dev/null; echo "0 2 * * * /path/to/backup.sh") | crontab -
```

## Monitoring Setup

```bash
# Install Prometheus and Grafana
docker run -d --name prometheus -p 9090:9090 prom/prometheus
docker run -d --name grafana -p 3000:3000 grafana/grafana

# Set up Node Exporter for system metrics
docker run -d --name node-exporter -p 9100:9100 prom/node-exporter

# Configure Prometheus to scrape metrics
cat > prometheus.yml << EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'node'
    static_configs:
      - targets: ['localhost:9100']
  
  - job_name: 'api'
    static_configs:
      - targets: ['localhost:3001']
EOF

# Restart Prometheus with new configuration
docker restart prometheus
```

## Security Hardening

```bash
# Set up firewall
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# Configure fail2ban
sudo apt install -y fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Set up automatic security updates
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

## Logging Configuration

```bash
# Set up centralized logging with ELK stack
docker run -d --name elasticsearch -p 9200:9200 -p 9300:9300 -e "discovery.type=single-node" elasticsearch:7.10.1
docker run -d --name kibana -p 5601:5601 --link elasticsearch:elasticsearch kibana:7.10.1
docker run -d --name logstash -p 5000:5000 --link elasticsearch:elasticsearch logstash:7.10.1

# Configure application logging
cat > logstash.conf << EOF
input {
  file {
    path => "/var/log/therapy-transcript-processor/*.log"
    start_position => "beginning"
  }
}

filter {
  json {
    source => "message"
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "therapy-transcript-processor-%{+YYYY.MM.dd}"
  }
}
EOF
```

## Scaling Configuration

```bash
# Set up auto-scaling with Docker Swarm
docker swarm init

# Create Docker stack file
cat > docker-stack.yml << EOF
version: '3'

services:
  mongodb:
    image: mongo:latest
    volumes:
      - mongodb_data:/data/db
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
    networks:
      - app-network

  backend:
    image: therapy-transcript-processor-backend:latest
    deploy:
      replicas: 2
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
    env_file:
      - .env
    networks:
      - app-network

  frontend:
    image: therapy-transcript-processor-frontend:latest
    deploy:
      replicas: 2
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '0.5'
          memory: 256M
    networks:
      - app-network

networks:
  app-network:
    driver: overlay

volumes:
  mongodb_data:
EOF

# Deploy the stack
docker stack deploy -c docker-stack.yml therapy-transcript-processor
```

## Maintenance Procedures

### Application Updates

```bash
# Pull latest code
git pull origin main

# Build new Docker images
docker-compose build

# Update running containers
docker-compose up -d
```

### Database Maintenance

```bash
# Connect to MongoDB
docker exec -it therapy-transcript-processor_mongodb_1 mongo

# Compact database
db.runCommand({ compact: 'transcripts' })

# Repair database
db.repairDatabase()
```

### SSL Certificate Renewal

```bash
# Renew Let's Encrypt certificates
sudo certbot renew
```

### System Updates

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Reboot if necessary
sudo reboot
```
