import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import userController from '../controllers/userController';
import Analysis from '../models/Analysis';
import Transcript from '../models/Transcript';

/**
 * Service for handling AI processing of transcripts
 */
class AiProcessingService {
  /**
   * Initialize OpenAI client with user's API key
   */
  private async getOpenAiClient(userId: string): Promise<OpenAI> {
    const keys = await userController.getApiKeys(userId);
    
    if (!keys.openAiApiKey) {
      throw new Error('OpenAI API key not found');
    }
    
    return new OpenAI({
      apiKey: keys.openAiApiKey
    });
  }
  
  /**
   * Initialize Anthropic client with user's API key
   */
  private async getAnthropicClient(userId: string): Promise<Anthropic> {
    const keys = await userController.getApiKeys(userId);
    
    if (!keys.anthropicApiKey) {
      throw new Error('Anthropic API key not found');
    }
    
    return new Anthropic({
      apiKey: keys.anthropicApiKey
    });
  }
  
  /**
   * Process transcript with OpenAI
   */
  private async processWithOpenAI(userId: string, transcriptText: string, analysisId: string): Promise<void> {
    try {
      const openai = await this.getOpenAiClient(userId);
      const analysis = await Analysis.findById(analysisId);
      
      if (!analysis) {
        throw new Error('Analysis not found');
      }
      
      // Update status
      analysis.status = 'processing';
      await analysis.save();
      
      // Prepare the prompt based on TypingMind guidelines
      const systemPrompt = this.getSystemPrompt();
      
      // Process SOAP note components
      const soapComponents = await this.generateSoapComponents(openai, systemPrompt, transcriptText);
      
      // Update analysis with SOAP components
      analysis.soapNote = {
        subjective: soapComponents.subjective,
        objective: soapComponents.objective,
        assessment: soapComponents.assessment,
        plan: soapComponents.plan
      };
      await analysis.save();
      
      // Process supplemental analyses
      const supplementalAnalyses = await this.generateSupplementalAnalyses(openai, systemPrompt, transcriptText);
      
      // Update analysis with supplemental analyses
      analysis.supplementalAnalyses = supplementalAnalyses;
      analysis.status = 'completed';
      await analysis.save();
      
    } catch (error) {
      console.error('OpenAI processing error:', error);
      
      // Update analysis with error
      const analysis = await Analysis.findById(analysisId);
      if (analysis) {
        analysis.status = 'failed';
        analysis.error = `OpenAI processing error: ${error}`;
        await analysis.save();
      }
    }
  }
  
  /**
   * Process transcript with Anthropic
   */
  private async processWithAnthropic(userId: string, transcriptText: string, analysisId: string): Promise<void> {
    try {
      const anthropic = await this.getAnthropicClient(userId);
      const analysis = await Analysis.findById(analysisId);
      
      if (!analysis) {
        throw new Error('Analysis not found');
      }
      
      // Update status
      analysis.status = 'processing';
      await analysis.save();
      
      // Prepare the prompt based on TypingMind guidelines
      const systemPrompt = this.getSystemPrompt();
      
      // Process SOAP note components
      const soapComponents = await this.generateSoapComponentsAnthropic(anthropic, systemPrompt, transcriptText);
      
      // Update analysis with SOAP components
      analysis.soapNote = {
        subjective: soapComponents.subjective,
        objective: soapComponents.objective,
        assessment: soapComponents.assessment,
        plan: soapComponents.plan
      };
      await analysis.save();
      
      // Process supplemental analyses
      const supplementalAnalyses = await this.generateSupplementalAnalysesAnthropic(anthropic, systemPrompt, transcriptText);
      
      // Update analysis with supplemental analyses
      analysis.supplementalAnalyses = supplementalAnalyses;
      analysis.status = 'completed';
      await analysis.save();
      
    } catch (error) {
      console.error('Anthropic processing error:', error);
      
      // Update analysis with error
      const analysis = await Analysis.findById(analysisId);
      if (analysis) {
        analysis.status = 'failed';
        analysis.error = `Anthropic processing error: ${error}`;
        await analysis.save();
      }
    }
  }
  
  /**
   * Generate SOAP components using OpenAI
   */
  private async generateSoapComponents(openai: OpenAI, systemPrompt: string, transcriptText: string): Promise<any> {
    // Subjective section
    const subjectiveResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Generate the Subjective section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Objective section
    const objectiveResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Generate the Objective section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Assessment section
    const assessmentResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Generate the Assessment section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Plan section
    const planResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Generate the Plan section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    return {
      subjective: subjectiveResponse.choices[0]?.message.content || '',
      objective: objectiveResponse.choices[0]?.message.content || '',
      assessment: assessmentResponse.choices[0]?.message.content || '',
      plan: planResponse.choices[0]?.message.content || ''
    };
  }
  
  /**
   * Generate supplemental analyses using OpenAI
   */
  private async generateSupplementalAnalyses(openai: OpenAI, systemPrompt: string, transcriptText: string): Promise<any> {
    // Key Points
    const keyPointsResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Extract the Key Points from this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 1500
    });
    
    // Significant Quotes
    const quotesResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Identify Significant Quotes from this therapy transcript (do not include minute markers):\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 1500
    });
    
    // Tonal Analysis
    const tonalResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Perform a detailed Tonal Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Thematic Analysis
    const thematicResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Perform a detailed Thematic Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Sentiment Analysis
    const sentimentResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Perform a detailed Sentiment Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Narrative Summary
    const summaryResponse = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Create a Comprehensive Narrative Summary of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    return {
      keyPoints: keyPointsResponse.choices[0]?.message.content || '',
      significantQuotes: quotesResponse.choices[0]?.message.content || '',
      tonalAnalysis: tonalResponse.choices[0]?.message.content || '',
      thematicAnalysis: thematicResponse.choices[0]?.message.content || '',
      sentimentAnalysis: sentimentResponse.choices[0]?.message.content || '',
      narrativeSummary: summaryResponse.choices[0]?.message.content || ''
    };
  }
  
  /**
   * Generate SOAP components using Anthropic
   */
  private async generateSoapComponentsAnthropic(anthropic: Anthropic, systemPrompt: string, transcriptText: string): Promise<any> {
    // Subjective section
    const subjectiveResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Generate the Subjective section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Objective section
    const objectiveResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Generate the Objective section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Assessment section
    const assessmentResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Generate the Assessment section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Plan section
    const planResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Generate the Plan section of a SOAP note based on this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    return {
      subjective: subjectiveResponse.content[0]?.text || '',
      objective: objectiveResponse.content[0]?.text || '',
      assessment: assessmentResponse.content[0]?.text || '',
      plan: planResponse.content[0]?.text || ''
    };
  }
  
  /**
   * Generate supplemental analyses using Anthropic
   */
  private async generateSupplementalAnalysesAnthropic(anthropic: Anthropic, systemPrompt: string, transcriptText: string): Promise<any> {
    // Key Points
    const keyPointsResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Extract the Key Points from this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 1500
    });
    
    // Significant Quotes
    const quotesResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Identify Significant Quotes from this therapy transcript (do not include minute markers):\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 1500
    });
    
    // Tonal Analysis
    const tonalResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Perform a detailed Tonal Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Thematic Analysis
    const thematicResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Perform a detailed Thematic Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Sentiment Analysis
    const sentimentResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Perform a detailed Sentiment Analysis of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    // Narrative Summary
    const summaryResponse = await anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Create a Comprehensive Narrative Summary of this therapy transcript:\n\n${transcriptText}` }
      ],
      temperature: 0.3,
      max_tokens: 2000
    });
    
    return {
      keyPoints: keyPointsResponse.content[0]?.text || '',
      significantQuotes: quotesResponse.content[0]?.text || '',
      tonalAnalysis: tonalResponse.content[0]?.text || '',
      thematicAnalysis: thematicResponse.content[0]?.text || '',
      sentimentAnalysis: sentimentResponse.content[0]?.text || '',
      narrativeSummary: summaryResponse.content[0]?.text || ''
    };
  }
  
  /**
   * Get system prompt based on TypingMind guidelines
   */
  private getSystemPrompt(): string {
    return `You are a highly skilled and experienced therapist specializing in creating comprehensive and insightful clinical progress notes. Your task is to analyze a provided counseling session transcript and generate a detailed progress note, suitable for an Electronic Medical Record (EMR), that mirrors the depth, detail, and clinical sophistication of an expert human therapist.

This task requires an iterative and multi-faceted approach, mimicking the internal process of a trained clinician. This includes:

1. Implicit Knowledge Application: You possess implicit knowledge of mental health counseling note construction, therapeutic modalities (including, but not limited to, Acceptance and Commitment Therapy, DBT, Narrative Therapy, and Existentialism), and various analytical approaches (tonal, thematic, sentiment analysis, identification of defense mechanisms, and assessment of transference/countertransference). Apply this knowledge throughout your analysis.

2. Iterative Analysis: The process is not linear. Perform multiple readings of the transcript, progressively building your understanding and refining your output.

3. Depth of Analysis: Go beyond surface-level observations. Seek deeper meaning, connections, and patterns within the transcript. Aim for a high degree of clinical nuance and sophistication.

4. Clinical Reasoning: Constantly ask yourself:
   - What does this mean clinically?
   - What are the underlying issues and dynamics?
   - How does this inform the treatment plan?
   - What are the client's strengths, resources, and vulnerabilities?
   - What are the potential risks and protective factors?
   - Whi
(Content truncated due to size limit. Use line ranges to read in chunks)