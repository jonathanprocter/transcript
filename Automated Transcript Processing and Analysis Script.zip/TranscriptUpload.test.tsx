import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '../context/AuthContext';
import TranscriptUpload from '../pages/TranscriptUpload';

// Mock the useNavigate hook
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

// Mock axios
jest.mock('axios', () => ({
  post: jest.fn().mockImplementation(() => Promise.resolve({ data: { transcript: { id: '123' } } })),
}));

// Mock the useAuth hook
jest.mock('../context/AuthContext', () => ({
  ...jest.requireActual('../context/AuthContext'),
  useAuth: () => ({
    user: {
      hasOpenAiKey: true,
      hasAnthropicKey: false
    }
  }),
}));

describe('TranscriptUpload Component', () => {
  const renderTranscriptUpload = () => {
    return render(
      <BrowserRouter>
        <AuthProvider>
          <TranscriptUpload />
        </AuthProvider>
      </BrowserRouter>
    );
  };

  test('renders upload form correctly', () => {
    renderTranscriptUpload();
    
    // Check for form elements
    expect(screen.getByText(/Upload Therapy Transcript/i)).toBeInTheDocument();
    expect(screen.getByText(/Drag & Drop or Click to Upload/i)).toBeInTheDocument();
    expect(screen.getByText(/PDF files only/i)).toBeInTheDocument();
  });

  test('shows error when non-PDF file is selected', async () => {
    renderTranscriptUpload();
    
    // Create a non-PDF file
    const file = new File(['test content'], 'test.txt', { type: 'text/plain' });
    
    // Simulate file selection
    const input = screen.getByLabelText(/Drag & Drop or Click to Upload/i, { selector: 'input' });
    fireEvent.change(input, { target: { files: [file] } });
    
    // Check for error message
    expect(await screen.findByText(/Only PDF files are allowed/i)).toBeInTheDocument();
  });

  test('shows error when trying to upload without selecting a file', async () => {
    renderTranscriptUpload();
    
    // Try to upload without selecting a file
    const uploadButton = screen.getByRole('button', { name: /Upload Transcript/i });
    fireEvent.click(uploadButton);
    
    // Check for error message
    expect(await screen.findByText(/Please select a file to upload/i)).toBeInTheDocument();
  });

  test('displays selected file information when PDF is selected', async () => {
    renderTranscriptUpload();
    
    // Create a PDF file
    const file = new File(['test content'], 'test.pdf', { type: 'application/pdf' });
    Object.defineProperty(file, 'size', { value: 1024 * 1024 }); // 1MB
    
    // Simulate file selection
    const input = screen.getByLabelText(/Drag & Drop or Click to Upload/i, { selector: 'input' });
    fireEvent.change(input, { target: { files: [file] } });
    
    // Check that file info is displayed
    expect(screen.getByText('test.pdf')).toBeInTheDocument();
    expect(screen.getByText('1.00 MB')).toBeInTheDocument();
  });

  test('upload button is enabled when PDF file is selected', async () => {
    renderTranscriptUpload();
    
    // Create a PDF file
    const file = new File(['test content'], 'test.pdf', { type: 'application/pdf' });
    
    // Simulate file selection
    const input = screen.getByLabelText(/Drag & Drop or Click to Upload/i, { selector: 'input' });
    fireEvent.change(input, { target: { files: [file] } });
    
    // Check that upload button is enabled
    const uploadButton = screen.getByRole('button', { name: /Upload Transcript/i });
    expect(uploadButton).not.toBeDisabled();
  });

  test('accessibility: all interactive elements have accessible names', () => {
    renderTranscriptUpload();
    
    // Check that all buttons have accessible names
    const buttons = screen.getAllByRole('button');
    buttons.forEach(button => {
      expect(button).toHaveAccessibleName();
    });
    
    // Check that all inputs have accessible names
    const inputs = screen.getAllByRole('textbox');
    inputs.forEach(input => {
      expect(input).toHaveAccessibleName();
    });
  });
});
