import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ErrorAlert from '../components/ErrorAlert';
import LoadingSpinner from '../components/LoadingSpinner';

const TranscriptView: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // Simulated transcript data
  const transcript = {
    id: '123',
    title: 'Therapy Session - May 15, 2025',
    clientName: 'John D.',
    date: '2025-05-15',
    duration: '50 minutes',
    content: `Therapist: Good morning, John. How are you feeling today?

Client: I'm doing okay, I guess. Had a bit of a rough week.

Therapist: I'm sorry to hear that. Can you tell me more about what made it rough?

Client: Work has been really stressful. My boss keeps adding more to my plate without any recognition of how much I'm already handling. And then at home, my partner and I had a few arguments about household responsibilities.

Therapist: That sounds like a lot to manage. Let's talk through both of these situations. How have you been coping with the increased workload?

Client: Not well, to be honest. I've been staying late, missing meals, and I can feel my anxiety creeping back up. I had trouble sleeping a few nights this week.

Therapist: I notice you mentioned your anxiety returning. Are you experiencing any of the physical symptoms we've discussed before?

Client: Yeah, the tightness in my chest is back, and I caught myself doing that rapid breathing thing when I got an email from my boss yesterday.

Therapist: Thank you for sharing that. It's important that we monitor these symptoms. Let's work on some strategies to help manage both the work situation and the anxiety response...`
  };
  
  const handleStartAnalysis = () => {
    navigate(`/analysis`);
  };
  
  return (
    <div className="transcript-view-container">
      <header className="transcript-header">
        <h1>{transcript.title}</h1>
        <div className="transcript-meta">
          <div className="meta-item">
            <span className="meta-label">Client:</span>
            <span className="meta-value">{transcript.clientName}</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">Date:</span>
            <span className="meta-value">{new Date(transcript.date).toLocaleDateString()}</span>
          </div>
          <div className="meta-item">
            <span className="meta-label">Duration:</span>
            <span className="meta-value">{transcript.duration}</span>
          </div>
        </div>
      </header>
      
      {error && (
        <ErrorAlert 
          message={error} 
          onDismiss={() => setError(null)} 
        />
      )}
      
      <div className="transcript-content-container">
        <div className="transcript-content">
          <pre>{transcript.content}</pre>
        </div>
        
        <div className="transcript-actions">
          <button
            className="btn btn-primary analyze-button"
            onClick={handleStartAnalysis}
            disabled={loading || !user}
          >
            {loading ? (
              <>
                <LoadingSpinner size="small" />
                <span>Processing...</span>
              </>
            ) : (
              'Generate Clinical Analysis'
            )}
          </button>
          
          {!user?.hasOpenAiKey && !user?.hasAnthropicKey && (
            <div className="api-key-warning">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
                <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>
              </svg>
              <span>API key required. Please configure in Settings.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TranscriptView;
