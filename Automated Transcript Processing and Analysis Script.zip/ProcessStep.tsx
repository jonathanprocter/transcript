import React, { useState, useEffect } from 'react';

interface ProcessStepProps {
  step: string;
  status: 'pending' | 'in-progress' | 'completed' | 'failed';
  description: string;
  progress?: number;
}

const ProcessStep: React.FC<ProcessStepProps> = ({
  step,
  status,
  description,
  progress = 0
}) => {
  // Status icon based on current status
  const getStatusIcon = () => {
    switch (status) {
      case 'pending':
        return (
          <div className="step-icon pending">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
            </svg>
          </div>
        );
      case 'in-progress':
        return (
          <div className="step-icon in-progress">
            <svg className="spinner" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
              <path className="spinner-path" d="M12 2v4c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6h-4c0 5.52 4.48 10 10 10s10-4.48 10-10-4.48-10-10-10z"/>
            </svg>
          </div>
        );
      case 'completed':
        return (
          <div className="step-icon completed">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
        );
      case 'failed':
        return (
          <div className="step-icon failed">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className={`process-step ${status}`}>
      {getStatusIcon()}
      
      <div className="step-content">
        <div className="step-header">
          <h4 className="step-title">{step}</h4>
          <span className="step-status">{status.replace('-', ' ')}</span>
        </div>
        
        <p className="step-description">{description}</p>
        
        {status === 'in-progress' && progress > 0 && (
          <div className="step-progress">
            <div className="progress-track">
              <div 
                className="progress-fill" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <span className="progress-percentage">{progress}%</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProcessStep;
