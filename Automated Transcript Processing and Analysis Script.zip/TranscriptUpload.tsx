import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ErrorAlert from '../components/ErrorAlert';
import LoadingSpinner from '../components/LoadingSpinner';

const TranscriptUpload: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (!selectedFile) {
      setFile(null);
      return;
    }
    
    // Check if file is PDF
    if (selectedFile.type !== 'application/pdf') {
      setError('Only PDF files are allowed');
      setFile(null);
      return;
    }
    
    setFile(selectedFile);
    setError(null);
  };
  
  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file to upload');
      return;
    }
    
    // Check if API keys are configured
    if (!user) {
      setError('You must be logged in to upload transcripts');
      return;
    }
    
    const hasOpenAiKey = user?.hasOpenAiKey || false;
    const hasAnthropicKey = user?.hasAnthropicKey || false;
    
    if (!hasOpenAiKey && !hasAnthropicKey) {
      setError('Please configure at least one AI provider API key in Settings before uploading');
      return;
    }
    
    try {
      setUploading(true);
      setError(null);
      
      // Create form data
      const formData = new FormData();
      formData.append('transcript', file);
      
      // For demo purposes, simulate upload progress
      const uploadInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 95) {
            clearInterval(uploadInterval);
            return 95;
          }
          return prev + 5;
        });
      }, 200);
      
      // Simulate API call
      setTimeout(() => {
        clearInterval(uploadInterval);
        setProgress(100);
        
        // Navigate to transcript view page
        setTimeout(() => {
          setUploading(false);
          navigate('/transcript/123');
        }, 500);
      }, 3000);
      
      // In a real implementation, this would be an actual API call:
      /*
      const response = await axios.post('/api/transcripts', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / (progressEvent.total || 100)
          );
          setProgress(percentCompleted);
        }
      });
      
      setUploading(false);
      navigate(`/transcript/${response.data.transcript.id}`);
      */
      
    } catch (err: any) {
      setUploading(false);
      setError(err.response?.data?.message || 'Failed to upload transcript');
    }
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  return (
    <div className="upload-container">
      <header className="upload-header">
        <h1>Upload Therapy Transcript</h1>
        <p className="upload-description">
          Upload a therapy session transcript to generate a comprehensive clinical progress note
        </p>
      </header>
      
      {error && (
        <ErrorAlert 
          message={error} 
          onDismiss={() => setError(null)} 
        />
      )}
      
      <div className="upload-card">
        <div className="upload-area">
          <input
            type="file"
            id="transcript-upload"
            className="file-input"
            onChange={handleFileChange}
            accept=".pdf"
            disabled={uploading}
          />
          <label htmlFor="transcript-upload" className="file-drop-area">
            <div className="upload-icon">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="48" height="48">
                <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/>
              </svg>
            </div>
            <div className="upload-text">
              <span className="upload-title">Drag & Drop or Click to Upload</span>
              <span className="upload-subtitle">PDF files only</span>
            </div>
          </label>
        </div>
        
        {file && (
          <div className="file-info">
            <div className="file-details">
              <div className="file-name">{file.name}</div>
              <div className="file-size">{formatFileSize(file.size)}</div>
            </div>
            <button 
              className="btn btn-outline remove-file"
              onClick={() => setFile(null)}
              disabled={uploading}
            >
              Remove
            </button>
          </div>
        )}
        
        {uploading && (
          <div className="upload-progress">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="progress-text">{progress}% Uploaded</div>
          </div>
        )}
        
        <div className="upload-actions">
          <button
            className="btn btn-primary upload-button"
            onClick={handleUpload}
            disabled={!file || uploading}
          >
            {uploading ? (
              <>
                <LoadingSpinner size="small" />
                <span>Uploading...</span>
              </>
            ) : (
              'Upload Transcript'
            )}
          </button>
        </div>
      </div>
      
      <div className="upload-help">
        <h3>Tips for Best Results</h3>
        <ul>
          <li>Ensure the PDF contains extractable text (not just images)</li>
          <li>Verify that speaker labels are clearly indicated</li>
          <li>Check that the full session is included from beginning to end</li>
          <li>For optimal results, use transcripts with minimal background noise</li>
        </ul>
      </div>
    </div>
  );
};

export default TranscriptUpload;
