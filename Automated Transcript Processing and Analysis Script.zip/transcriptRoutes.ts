import { Router } from 'express';
import transcriptController from '../controllers/transcriptController';
import { auth } from '../middleware/auth';

const router = Router();

// All routes require authentication
router.use(auth);

// Transcript routes
router.post('/upload', transcriptController.uploadTranscript);
router.get('/', transcriptController.getAllTranscripts);
router.get('/:id', transcriptController.getTranscript);
router.delete('/:id', transcriptController.deleteTranscript);

export default router;
