import { Request, Response } from 'express';
import User, { IUser } from '../models/User';
import encryptionService from '../utils/encryptionService';

/**
 * User controller for handling authentication and user management
 */
class UserController {
  /**
   * Register a new user
   */
  async register(req: Request, res: Response) {
    try {
      const { email, password, firstName, lastName, role } = req.body;
      
      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }
      
      // Create new user
      const user = new User({
        email,
        password,
        firstName,
        lastName,
        role: role || 'therapist',
      });
      
      // Save user to database
      await user.save();
      
      // Generate auth token
      const token = user.generateAuthToken();
      
      res.status(201).json({
        message: 'User registered successfully',
        token,
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Server error during registration' });
    }
  }
  
  /**
   * Login user
   */
  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      
      // Find user by email
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Check password
      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Generate auth token
      const token = user.generateAuthToken();
      
      res.status(200).json({
        message: 'Login successful',
        token,
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Server error during login' });
    }
  }
  
  /**
   * Get current user profile
   */
  async getProfile(req: Request, res: Response) {
    try {
      const user = req.user as IUser;
      
      res.status(200).json({
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          hasOpenAiKey: !!user.openAiApiKey,
          hasAnthropicKey: !!user.anthropicApiKey,
        },
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({ message: 'Server error retrieving profile' });
    }
  }
  
  /**
   * Save API keys
   */
  async saveApiKeys(req: Request, res: Response) {
    try {
      const user = req.user as IUser;
      const { openAiApiKey, anthropicApiKey } = req.body;
      
      // Encrypt API keys before storing
      if (openAiApiKey) {
        user.openAiApiKey = encryptionService.encrypt(openAiApiKey);
      }
      
      if (anthropicApiKey) {
        user.anthropicApiKey = encryptionService.encrypt(anthropicApiKey);
      }
      
      await user.save();
      
      res.status(200).json({
        message: 'API keys saved successfully',
        hasOpenAiKey: !!user.openAiApiKey,
        hasAnthropicKey: !!user.anthropicApiKey,
      });
    } catch (error) {
      console.error('Save API keys error:', error);
      res.status(500).json({ message: 'Server error saving API keys' });
    }
  }
  
  /**
   * Get API keys (for internal use only)
   */
  async getApiKeys(userId: string) {
    try {
      const user = await User.findById(userId);
      
      if (!user) {
        throw new Error('User not found');
      }
      
      const keys = {
        openAiApiKey: user.openAiApiKey ? encryptionService.decrypt(user.openAiApiKey) : null,
        anthropicApiKey: user.anthropicApiKey ? encryptionService.decrypt(user.anthropicApiKey) : null,
      };
      
      return keys;
    } catch (error) {
      console.error('Get API keys error:', error);
      throw new Error('Error retrieving API keys');
    }
  }
  
  /**
   * Delete API keys
   */
  async deleteApiKeys(req: Request, res: Response) {
    try {
      const user = req.user as IUser;
      const { openAi, anthropic } = req.body;
      
      if (openAi) {
        user.openAiApiKey = undefined;
      }
      
      if (anthropic) {
        user.anthropicApiKey = undefined;
      }
      
      await user.save();
      
      res.status(200).json({
        message: 'API keys deleted successfully',
        hasOpenAiKey: !!user.openAiApiKey,
        hasAnthropicKey: !!user.anthropicApiKey,
      });
    } catch (error) {
      console.error('Delete API keys error:', error);
      res.status(500).json({ message: 'Server error deleting API keys' });
    }
  }
}

export default new UserController();
