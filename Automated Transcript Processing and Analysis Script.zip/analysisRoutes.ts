import { Router } from 'express';
import analysisController from '../controllers/analysisController';
import { auth } from '../middleware/auth';

const router = Router();

// All routes require authentication
router.use(auth);

// Analysis routes
router.post('/', analysisController.createAnalysis);
router.get('/:id', analysisController.getAnalysis);
router.get('/transcript/:transcriptId', analysisController.getAnalysesForTranscript);
router.delete('/:id', analysisController.deleteAnalysis);

export default router;
