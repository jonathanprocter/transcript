document.addEventListener('DOMContentLoaded', function() {
    // User menu dropdown
    const userInfo = document.querySelector('.user-info');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    
    if (userInfo && dropdownMenu) {
        userInfo.addEventListener('click', function() {
            dropdownMenu.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!userInfo.contains(e.target)) {
                dropdownMenu.classList.remove('active');
            }
        });
    }
    
    // Upload button functionality
    const uploadBtn = document.getElementById('upload-btn');
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            window.location.href = 'upload.html';
        });
    }
    
    // Action buttons functionality
    const viewBtns = document.querySelectorAll('.view-btn:not([disabled])');
    const editBtns = document.querySelectorAll('.edit-btn:not([disabled])');
    const downloadBtns = document.querySelectorAll('.download-btn');
    const deleteBtns = document.querySelectorAll('.delete-btn');
    const cancelBtns = document.querySelectorAll('.cancel-btn');
    const startBtns = document.querySelectorAll('.start-btn');
    
    viewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            // In a real app, this would navigate to the transcript view page with an ID
            alert(`Viewing transcript: ${transcriptName}`);
        });
    });
    
    editBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            // In a real app, this would navigate to the edit page with an ID
            alert(`Editing transcript: ${transcriptName}`);
        });
    });
    
    downloadBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            // In a real app, this would trigger a download
            alert(`Downloading transcript: ${transcriptName}`);
        });
    });
    
    deleteBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            if (confirm(`Are you sure you want to delete "${transcriptName}"?`)) {
                // In a real app, this would send a delete request to the server
                row.remove();
                alert(`Transcript deleted: ${transcriptName}`);
            }
        });
    });
    
    cancelBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            if (confirm(`Are you sure you want to cancel processing for "${transcriptName}"?`)) {
                // In a real app, this would send a cancel request to the server
                const statusCell = row.querySelector('td:nth-child(3)');
                statusCell.innerHTML = '<span class="status-badge pending">Pending</span>';
                alert(`Processing canceled for: ${transcriptName}`);
            }
        });
    });
    
    startBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const transcriptName = row.querySelector('td:first-child').textContent;
            // In a real app, this would send a start processing request to the server
            const statusCell = row.querySelector('td:nth-child(3)');
            statusCell.innerHTML = '<span class="status-badge processing">Processing</span>';
            
            // Update action buttons
            const actionsCell = row.querySelector('td:last-child');
            actionsCell.innerHTML = `
                <div class="action-buttons">
                    <button class="action-btn view-btn" title="View" disabled>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                        </svg>
                    </button>
                    <button class="action-btn edit-btn" title="Edit" disabled>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                            <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                        </svg>
                    </button>
                    <button class="action-btn cancel-btn" title="Cancel">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                        </svg>
                    </button>
                </div>
            `;
            
            // Add event listener to the new cancel button
            const newCancelBtn = actionsCell.querySelector('.cancel-btn');
            newCancelBtn.addEventListener('click', function() {
                if (confirm(`Are you sure you want to cancel processing for "${transcriptName}"?`)) {
                    statusCell.innerHTML = '<span class="status-badge pending">Pending</span>';
                    actionsCell.innerHTML = `
                        <div class="action-buttons">
                            <button class="action-btn start-btn" title="Start Processing">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                                    <path d="M8 5v14l11-7z"/>
                                </svg>
                            </button>
                            <button class="action-btn edit-btn" title="Edit">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                                    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                                </svg>
                            </button>
                            <button class="action-btn delete-btn" title="Delete">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18">
                                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                </svg>
                            </button>
                        </div>
                    `;
                    alert(`Processing canceled for: ${transcriptName}`);
                }
            });
        });
    });
    
    // Simulate loading data
    function simulateDataLoading() {
        // In a real app, this would fetch data from the server
        console.log('Dashboard data loaded');
    }
    
    simulateDataLoading();
});
