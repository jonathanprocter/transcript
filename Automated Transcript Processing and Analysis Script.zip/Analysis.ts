import mongoose, { Document, Schema } from 'mongoose';

// Analysis interface
export interface IAnalysis extends Document {
  userId: mongoose.Types.ObjectId;
  transcriptId: mongoose.Types.ObjectId;
  provider: 'openai' | 'anthropic';
  model: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  error?: string;
  soapNote: {
    subjective: string;
    objective: string;
    assessment: string;
    plan: string;
  };
  supplementalAnalyses: {
    keyPoints: string;
    significantQuotes: string;
    tonalAnalysis: string;
    thematicAnalysis: string;
    sentimentAnalysis: string;
    narrativeSummary: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

// Analysis schema
const AnalysisSchema = new Schema<IAnalysis>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    transcriptId: {
      type: Schema.Types.ObjectId,
      ref: 'Transcript',
      required: true,
    },
    provider: {
      type: String,
      enum: ['openai', 'anthropic'],
      required: true,
    },
    model: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['pending', 'processing', 'completed', 'failed'],
      default: 'pending',
    },
    error: {
      type: String,
    },
    soapNote: {
      subjective: {
        type: String,
        default: '',
      },
      objective: {
        type: String,
        default: '',
      },
      assessment: {
        type: String,
        default: '',
      },
      plan: {
        type: String,
        default: '',
      },
    },
    supplementalAnalyses: {
      keyPoints: {
        type: String,
        default: '',
      },
      significantQuotes: {
        type: String,
        default: '',
      },
      tonalAnalysis: {
        type: String,
        default: '',
      },
      thematicAnalysis: {
        type: String,
        default: '',
      },
      sentimentAnalysis: {
        type: String,
        default: '',
      },
      narrativeSummary: {
        type: String,
        default: '',
      },
    },
  },
  {
    timestamps: true,
  }
);

// Create and export Analysis model
const Analysis = mongoose.model<IAnalysis>('Analysis', AnalysisSchema);
export default Analysis;
