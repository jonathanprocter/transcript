import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorAlert from '../components/ErrorAlert';

const ExportOptions = {
  PDF: 'pdf',
  DOCX: 'docx',
  TXT: 'txt',
  EMR: 'emr'
};

interface ExportModalProps {
  analysis: any;
  onClose: () => void;
  onExportComplete: (url: string, format: string) => void;
}

const ExportModal: React.FC<ExportModalProps> = ({ 
  analysis, 
  onClose,
  onExportComplete
}) => {
  const { user } = useAuth();
  
  const [exportFormat, setExportFormat] = useState<string>(ExportOptions.PDF);
  const [exportOptions, setExportOptions] = useState({
    includeSoapNote: true,
    includeKeyPoints: true,
    includeSignificantQuotes: true,
    includeTonalAnalysis: false,
    includeThematicAnalysis: false,
    includeSentimentAnalysis: false,
    includeNarrativeSummary: true
  });
  const [exporting, setExporting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const handleExportOptionChange = (option: string) => {
    setExportOptions({
      ...exportOptions,
      [option]: !exportOptions[option as keyof typeof exportOptions]
    });
  };
  
  const handleExport = async () => {
    try {
      setExporting(true);
      setError(null);
      
      // Call export API
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/api/analyses/${analysis._id}/export`,
        {
          format: exportFormat,
          options: exportOptions
        }
      );
      
      setExporting(false);
      
      // Handle successful export
      onExportComplete(response.data.url, exportFormat);
      onClose();
    } catch (err: any) {
      setExporting(false);
      setError(err.response?.data?.message || 'Failed to export analysis');
      console.error('Export error:', err);
    }
  };
  
  return (
    <div className="export-modal-overlay">
      <div className="export-modal">
        <div className="export-modal-header">
          <h2>Export Analysis</h2>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        
        {error && (
          <ErrorAlert 
            message={error} 
            onDismiss={() => setError(null)} 
          />
        )}
        
        <div className="export-modal-content">
          <div className="export-format-section">
            <h3>Export Format</h3>
            <div className="export-format-options">
              <div 
                className={`format-option ${exportFormat === ExportOptions.PDF ? 'selected' : ''}`}
                onClick={() => setExportFormat(ExportOptions.PDF)}
              >
                <div className="format-icon pdf-icon"></div>
                <span className="format-label">PDF</span>
              </div>
              
              <div 
                className={`format-option ${exportFormat === ExportOptions.DOCX ? 'selected' : ''}`}
                onClick={() => setExportFormat(ExportOptions.DOCX)}
              >
                <div className="format-icon docx-icon"></div>
                <span className="format-label">DOCX</span>
              </div>
              
              <div 
                className={`format-option ${exportFormat === ExportOptions.TXT ? 'selected' : ''}`}
                onClick={() => setExportFormat(ExportOptions.TXT)}
              >
                <div className="format-icon txt-icon"></div>
                <span className="format-label">Plain Text</span>
              </div>
              
              <div 
                className={`format-option ${exportFormat === ExportOptions.EMR ? 'selected' : ''}`}
                onClick={() => setExportFormat(ExportOptions.EMR)}
              >
                <div className="format-icon emr-icon"></div>
                <span className="format-label">EMR Format</span>
              </div>
            </div>
          </div>
          
          <div className="export-content-section">
            <h3>Content to Include</h3>
            <div className="export-content-options">
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeSoapNote} 
                  onChange={() => handleExportOptionChange('includeSoapNote')}
                  disabled={true} // SOAP Note is always required
                />
                <span className="checkbox-text">SOAP Note (required)</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeKeyPoints} 
                  onChange={() => handleExportOptionChange('includeKeyPoints')}
                />
                <span className="checkbox-text">Key Points</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeSignificantQuotes} 
                  onChange={() => handleExportOptionChange('includeSignificantQuotes')}
                />
                <span className="checkbox-text">Significant Quotes</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeTonalAnalysis} 
                  onChange={() => handleExportOptionChange('includeTonalAnalysis')}
                />
                <span className="checkbox-text">Tonal Analysis</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeThematicAnalysis} 
                  onChange={() => handleExportOptionChange('includeThematicAnalysis')}
                />
                <span className="checkbox-text">Thematic Analysis</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeSentimentAnalysis} 
                  onChange={() => handleExportOptionChange('includeSentimentAnalysis')}
                />
                <span className="checkbox-text">Sentiment Analysis</span>
              </label>
              
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={exportOptions.includeNarrativeSummary} 
                  onChange={() => handleExportOptionChange('includeNarrativeSummary')}
                />
                <span className="checkbox-text">Narrative Summary</span>
              </label>
            </div>
          </div>
          
          {exportFormat === ExportOptions.EMR && (
            <div className="emr-integration-section">
              <h3>EMR Integration</h3>
              <p className="emr-description">
                This will prepare the document in a format suitable for direct import into compatible EMR systems.
              </p>
              <div className="emr-warning">
                <div className="warning-icon">⚠️</div>
                <p>
                  Always review the generated document before importing into your EMR system. 
                  The therapist is responsible for the accuracy and appropriateness of all clinical documentation.
                </p>
              </div>
            </div>
          )}
        </div>
        
        <div className="export-modal-footer">
          <button className="cancel-button" onClick={onClose} disabled={exporting}>
            Cancel
          </button>
          <button 
            className="export-button"
            onClick={handleExport}
            disabled={exporting}
          >
            {exporting ? 'Exporting...' : 'Export Document'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExportModal;
