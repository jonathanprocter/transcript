# Deployment Guide: Therapy Transcript Processor

This document outlines the steps to deploy the Therapy Transcript Processor application to a staging environment for user review and testing.

## Prerequisites

- Node.js (v16+)
- MongoDB (v4.4+)
- Access to a cloud hosting provider (AWS, Azure, or Google Cloud)
- SSL certificate for secure HTTPS connections
- Domain name (optional for staging)

## Environment Setup

### 1. Environment Variables

Create a `.env` file in the backend directory with the following variables:

```
# Server Configuration
NODE_ENV=staging
PORT=5000
FRONTEND_URL=https://staging.therapytranscriptprocessor.com

# Database Configuration
MONGODB_URI=mongodb://username:password@hostname:port/database

# JWT Authentication
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRES_IN=24h

# Encryption Keys (for API key storage)
ENCRYPTION_KEY=your_32_character_encryption_key
ENCRYPTION_IV=your_16_character_encryption_iv

# Storage Configuration
STORAGE_TYPE=s3
S3_BUCKET_NAME=your-s3-bucket-name
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key

# Logging
LOG_LEVEL=info
```

### 2. Frontend Environment

Create a `.env` file in the frontend directory:

```
REACT_APP_API_URL=https://api-staging.therapytranscriptprocessor.com
REACT_APP_VERSION=0.1.0
```

## Backend Deployment

### 1. Prepare Backend for Deployment

```bash
cd /home/ubuntu/therapy_transcript_processor_app/backend

# Install production dependencies
npm ci --production

# Build TypeScript
npm run build
```

### 2. Deploy Backend to Server

#### Option A: Traditional Server Deployment

1. Set up a Node.js server with PM2:

```bash
# Install PM2 globally
npm install -g pm2

# Start the application with PM2
pm2 start dist/server.js --name therapy-transcript-processor-api

# Save PM2 configuration
pm2 save

# Set up PM2 to start on server boot
pm2 startup
```

2. Configure Nginx as a reverse proxy:

```nginx
server {
    listen 443 ssl;
    server_name api-staging.therapytranscriptprocessor.com;

    ssl_certificate /path/to/ssl/certificate.crt;
    ssl_certificate_key /path/to/ssl/private.key;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### Option B: Containerized Deployment

1. Create a Dockerfile in the backend directory:

```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --production

COPY dist/ ./dist/

EXPOSE 5000

CMD ["node", "dist/server.js"]
```

2. Build and push the Docker image:

```bash
docker build -t therapy-transcript-processor-api:staging .
docker tag therapy-transcript-processor-api:staging your-registry/therapy-transcript-processor-api:staging
docker push your-registry/therapy-transcript-processor-api:staging
```

3. Deploy using Docker Compose or Kubernetes

## Frontend Deployment

### 1. Build Frontend for Production

```bash
cd /home/ubuntu/therapy_transcript_processor_app/frontend

# Install dependencies
npm ci

# Build for production
npm run build
```

### 2. Deploy Frontend

#### Option A: Static Hosting (AWS S3 + CloudFront)

1. Upload build files to S3:

```bash
aws s3 sync build/ s3://your-s3-bucket-name/ --delete
```

2. Configure CloudFront distribution with HTTPS

#### Option B: Traditional Web Server

1. Configure Nginx to serve static files:

```nginx
server {
    listen 443 ssl;
    server_name staging.therapytranscriptprocessor.com;

    ssl_certificate /path/to/ssl/certificate.crt;
    ssl_certificate_key /path/to/ssl/private.key;

    root /var/www/therapy-transcript-processor;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## Database Setup

### MongoDB Configuration

1. Create a new MongoDB database for staging
2. Set up a database user with appropriate permissions
3. Configure network access to allow connections from your backend server
4. Enable MongoDB Atlas backups (if using Atlas)

## Security Considerations

### HIPAA Compliance Checklist

- [x] Enforce HTTPS for all connections
- [x] Implement proper authentication and authorization
- [x] Encrypt sensitive data at rest (API keys, patient information)
- [x] Set up proper access controls
- [x] Configure audit logging for all sensitive operations
- [x] Implement automatic session timeout
- [x] Ensure secure handling of PDF uploads and storage
- [x] Configure proper CORS settings
- [x] Set up regular security scanning

### Additional Security Measures

1. Configure Web Application Firewall (WAF)
2. Set up rate limiting to prevent abuse
3. Implement IP whitelisting for admin access
4. Configure Content Security Policy (CSP) headers
5. Enable regular security scanning

## Monitoring and Logging

1. Set up application monitoring using a service like New Relic or Datadog
2. Configure centralized logging with ELK stack or a similar solution
3. Set up alerts for critical errors and performance issues
4. Monitor API usage and rate limits

## Backup and Recovery

1. Configure daily database backups
2. Set up a backup retention policy
3. Document and test the recovery process
4. Implement a disaster recovery plan

## Staging Environment Access

Provide the following information to authorized users:

- Staging URL: https://staging.therapytranscriptprocessor.com
- Test account credentials (if applicable)
- Known limitations of the staging environment
- Feedback collection process

## Rollback Procedure

In case of critical issues:

1. Identify the issue and its scope
2. Communicate with stakeholders about the rollback
3. Restore the previous version of the application
4. Restore database from backup if necessary
5. Verify system functionality after rollback
6. Document the issue and rollback process

## Post-Deployment Verification

1. Verify all application features are working correctly
2. Test user authentication and authorization
3. Validate PDF upload and processing
4. Test AI analysis generation with both providers
5. Verify export functionality for all formats
6. Check responsive design on multiple devices
7. Validate accessibility features
8. Verify security headers and HTTPS configuration

## Demonstration Preparation

1. Create sample PDF transcripts for demonstration
2. Prepare a step-by-step demonstration script
3. Set up test accounts with pre-configured API keys
4. Prepare documentation for user review
5. Set up a feedback collection mechanism

## Final Checklist

- [ ] Backend deployed and accessible
- [ ] Frontend deployed and accessible
- [ ] Database properly configured and secured
- [ ] Environment variables set correctly
- [ ] SSL certificates installed and working
- [ ] Application features verified
- [ ] Monitoring and logging configured
- [ ] Backup procedures in place
- [ ] Documentation updated with staging information
- [ ] Demonstration materials prepared
