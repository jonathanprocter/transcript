import React from 'react';

interface LoadingSpinnerProps {
  message?: string;
  size?: 'small' | 'medium' | 'large';
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message = 'Loading...', size = 'medium' }) => {
  const getSpinnerSize = () => {
    switch (size) {
      case 'small':
        return { width: '20px', height: '20px' };
      case 'large':
        return { width: '48px', height: '48px' };
      case 'medium':
      default:
        return { width: '32px', height: '32px' };
    }
  };

  const spinnerSize = getSpinnerSize();
  
  return (
    <div className="loading-spinner-container">
      <div 
        className="loading-spinner" 
        style={spinnerSize}
      >
        <svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
          <circle 
            className="spinner-circle" 
            cx="25" 
            cy="25" 
            r="20" 
            fill="none" 
            strokeWidth="5"
          ></circle>
        </svg>
      </div>
      {message && <p className="loading-message">{message}</p>}
    </div>
  );
};

export default LoadingSpinner;
