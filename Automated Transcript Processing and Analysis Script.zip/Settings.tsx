import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import ErrorAlert from '../components/ErrorAlert';
import Notification from '../components/Notification';

const Settings: React.FC = () => {
  const { user, updateApiKeys } = useAuth();
  
  const [openAiKey, setOpenAiKey] = useState('');
  const [anthropicKey, setAnthropicKey] = useState('');
  const [showOpenAiKey, setShowOpenAiKey] = useState(false);
  const [showAnthropicKey, setShowAnthropicKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{
    show: boolean;
    type: 'success' | 'warning' | 'error' | 'info';
    message: string;
  }>({ show: false, type: 'success', message: '' });
  
  const handleSaveApiKeys = async () => {
    try {
      setSaving(true);
      setError(null);
      
      // Validate keys if provided
      if (openAiKey && !openAiKey.startsWith('sk-')) {
        setError('OpenAI API key should start with "sk-"');
        setSaving(false);
        return;
      }
      
      if (anthropicKey && !anthropicKey.startsWith('sk-ant-')) {
        setError('Anthropic API key should start with "sk-ant-"');
        setSaving(false);
        return;
      }
      
      // Update API keys
      await updateApiKeys({
        openAiKey: openAiKey || null,
        anthropicKey: anthropicKey || null
      });
      
      // Show success notification
      setNotification({
        show: true,
        type: 'success',
        message: 'API keys saved successfully'
      });
      
      // Clear form
      setOpenAiKey('');
      setAnthropicKey('');
      
      // Hide notification after 5 seconds
      setTimeout(() => {
        setNotification({ ...notification, show: false });
      }, 5000);
      
      setSaving(false);
    } catch (err: any) {
      setSaving(false);
      setError(err.response?.data?.message || 'Failed to save API keys');
    }
  };
  
  return (
    <div className="settings-container">
      <header className="settings-header">
        <h1>Settings</h1>
        <p className="settings-description">
          Configure your API keys and application preferences
        </p>
      </header>
      
      {error && (
        <ErrorAlert 
          message={error} 
          onDismiss={() => setError(null)} 
        />
      )}
      
      {notification.show && (
        <Notification
          type={notification.type}
          message={notification.message}
          onDismiss={() => setNotification({ ...notification, show: false })}
        />
      )}
      
      <div className="settings-card">
        <h2>API Configuration</h2>
        <p className="settings-card-description">
          Configure your AI provider API keys to enable transcript processing.
          You need at least one API key configured to use the application.
        </p>
        
        <div className="api-key-section">
          <h3>OpenAI API Key</h3>
          <p className="api-key-description">
            Used for GPT-4 powered analysis. Get your API key from the 
            <a href="https://platform.openai.com/account/api-keys" target="_blank" rel="noopener noreferrer">
              OpenAI Platform
            </a>.
          </p>
          
          <div className="api-key-status-indicator">
            <span className="status-label">Status:</span>
            <span className={`status-value ${user?.hasOpenAiKey ? 'configured' : 'not-configured'}`}>
              {user?.hasOpenAiKey ? 'Configured' : 'Not Configured'}
            </span>
          </div>
          
          <div className="form-group">
            <label htmlFor="openai-key" className="form-label">
              OpenAI API Key
            </label>
            <div className="api-key-input-container">
              <input
                type={showOpenAiKey ? "text" : "password"}
                id="openai-key"
                className="form-input"
                value={openAiKey}
                onChange={(e) => setOpenAiKey(e.target.value)}
                placeholder={user?.hasOpenAiKey ? "••••••••••••••••••••••••••••••" : "Enter your OpenAI API key"}
                aria-describedby="openai-key-help"
              />
              <button
                type="button"
                className="toggle-visibility-button"
                onClick={() => setShowOpenAiKey(!showOpenAiKey)}
                aria-label={showOpenAiKey ? "Hide OpenAI API key" : "Show OpenAI API key"}
              >
                {showOpenAiKey ? (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
                    <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
                    <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                  </svg>
                )}
              </button>
            </div>
            <p id="openai-key-help" className="form-help-text">
              Your API key is encrypted and stored securely. Leave blank to keep existing key.
            </p>
          </div>
        </div>
        
        <div className="api-key-section">
          <h3>Anthropic API Key</h3>
          <p className="api-key-description">
            Used for Claude 3 Opus powered analysis. Get your API key from the 
            <a href="https://console.anthropic.com/account/keys" target="_blank" rel="noopener noreferrer">
              Anthropic Console
            </a>.
          </p>
          
          <div className="api-key-status-indicator">
            <span className="status-label">Status:</span>
            <span className={`status-value ${user?.hasAnthropicKey ? 'configured' : 'not-configured'}`}>
              {user?.hasAnthropicKey ? 'Configured' : 'Not Configured'}
            </span>
          </div>
          
          <div className="form-group">
            <label htmlFor="anthropic-key" className="form-label">
              Anthropic API Key
            </label>
            <div className="api-key-input-container">
              <input
                type={showAnthropicKey ? "text" : "password"}
                id="anthropic-key"
                className="form-input"
                value={anthropicKey}
                onChange={(e) => setAnthropicKey(e.target.value)}
                placeholder={user?.hasAnthropicKey ? "••••••••••••••••••••••••••••••" : "Enter your Anthropic API key"}
                aria-describedby="anthropic-key-help"
              />
              <button
                type="button"
                className="toggle-visibility-button"
                onClick={() => setShowAnthropicKey(!showAnthropicKey)}
                aria-label={showAnthropicKey ? "Hide Anthropic API key" : "Show Anthropic API key"}
              >
                {showAnthropicKey ? (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
                    <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
                    <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                  </svg>
                )}
              </button>
            </div>
            <p id="anthropic-key-help" className="form-help-text">
              Your API key is encrypted and stored securely. Leave blank to keep existing key.
            </p>
          </div>
        </div>
        
        <div className="settings-actions">
          <button
            className="btn btn-primary save-button"
            onClick={handleSaveApiKeys}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save API Keys'}
          </button>
        </div>
      </div>
      
      <div className="settings-card">
        <h2>Application Preferences</h2>
        
        <div className="preference-section">
          <h3>Default AI Provider</h3>
          <p className="preference-description">
            Select which AI provider to use by default when generating analyses.
          </p>
          
          <div className="radio-group">
            <label className="radio-label">
              <input
                type="radio"
                name="default-provider"
                value="openai"
                defaultChecked={true}
              />
              <span className="radio-text">OpenAI (GPT-4)</span>
            </label>
            
            <label className="radio-label">
              <input
                type="radio"
                name="default-provider"
                value="anthropic"
              />
              <span className="radio-text">Anthropic (Claude 3 Opus)</span>
            </label>
          </div>
        </div>
        
        <div className="preference-section">
          <h3>Privacy Settings</h3>
          <p className="preference-description">
            Configure privacy and data handling preferences.
          </p>
          
          <div className="checkbox-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="local-processing"
                defaultChecked={true}
              />
              <span className="checkbox-text">Enable local-only processing when possible</span>
            </label>
            
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="auto-redaction"
                defaultChecked={true}
              />
              <span className="checkbox-text">Automatically redact sensitive identifiers in exported documents</span>
            </label>
            
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="session-timeout"
                defaultChecked={true}
              />
              <span className="checkbox-text">Automatically log out after 30 minutes of inactivity</span>
            </label>
          </div>
        </div>
        
        <div className="settings-actions">
          <button className="btn btn-primary save-button">
            Save Preferences
          </button>
        </div>
      </div>
      
      <div className="settings-card">
        <h2>Account Information</h2>
        
        <div className="account-info">
          <div className="info-item">
            <span className="info-label">Name:</span>
            <span className="info-value">{user ? `${user.firstName} ${user.lastName}` : 'N/A'}</span>
          </div>
          
          <div className="info-item">
            <span className="info-label">Email:</span>
            <span className="info-value">{user?.email || 'N/A'}</span>
          </div>
          
          <div className="info-item">
            <span className="info-label">Role:</span>
            <span className="info-value">{user?.role || 'N/A'}</span>
          </div>
          
          <div className="info-item">
            <span className="info-label">Account Created:</span>
            <span className="info-value">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}</span>
          </div>
        </div>
        
        <div className="account-actions">
          <button className="btn btn-outline">
            Change Password
          </button>
          
          <button className="btn btn-danger">
            Delete Account
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
