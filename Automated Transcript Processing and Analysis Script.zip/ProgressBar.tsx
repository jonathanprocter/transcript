import React, { useState, useEffect } from 'react';

interface ProgressBarProps {
  progress: number;
  status: string;
  showPercentage?: boolean;
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ 
  progress, 
  status, 
  showPercentage = true,
  className = ''
}) => {
  const [animatedProgress, setAnimatedProgress] = useState(0);
  
  // Animate progress changes
  useEffect(() => {
    // If progress is 0, reset immediately
    if (progress === 0) {
      setAnimatedProgress(0);
      return;
    }
    
    // Otherwise animate smoothly
    const animationFrame = requestAnimationFrame(() => {
      // Gradually approach target progress
      if (Math.abs(animatedProgress - progress) < 1) {
        setAnimatedProgress(progress);
      } else {
        setAnimatedProgress(prev => {
          const step = (progress - prev) * 0.2;
          return prev + step;
        });
      }
    });
    
    return () => cancelAnimationFrame(animationFrame);
  }, [progress, animatedProgress]);
  
  return (
    <div className={`progress-container ${className}`}>
      <div className="progress-track">
        <div 
          className={`progress-fill ${status}`} 
          style={{ width: `${animatedProgress}%` }}
        ></div>
      </div>
      
      {showPercentage && (
        <div className="progress-percentage">
          {Math.round(animatedProgress)}%
        </div>
      )}
      
      <div className="progress-status">
        {status}
      </div>
    </div>
  );
};

export default ProgressBar;
