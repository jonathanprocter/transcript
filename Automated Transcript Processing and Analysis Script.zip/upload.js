document.addEventListener('DOMContentLoaded', function() {
    // User menu dropdown
    const userInfo = document.querySelector('.user-info');
    const dropdownMenu = document.querySelector('.dropdown-menu');
    
    if (userInfo && dropdownMenu) {
        userInfo.addEventListener('click', function() {
            dropdownMenu.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!userInfo.contains(e.target)) {
                dropdownMenu.classList.remove('active');
            }
        });
    }
    
    // Upload functionality
    const uploadArea = document.getElementById('upload-area');
    const fileUpload = document.getElementById('file-upload');
    const uploadPreview = document.getElementById('upload-preview');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const removeFile = document.getElementById('remove-file');
    const nextStep1 = document.getElementById('next-step-1');
    const backToDashboard = document.getElementById('back-to-dashboard');
    
    // Step navigation
    const steps = document.querySelectorAll('.step');
    const stepContentPanels = document.querySelectorAll('.step-content-panel');
    const prevStep2 = document.getElementById('prev-step-2');
    const nextStep2 = document.getElementById('next-step-2');
    const cancelProcessing = document.getElementById('cancel-processing');
    
    // Processing elements
    const processingSpinner = document.getElementById('processing-spinner');
    const successIcon = document.getElementById('success-icon');
    const processingStatusText = document.getElementById('processing-status-text');
    const processingDetails = document.getElementById('processing-details');
    const progressFill = document.getElementById('progress-fill');
    const progressSteps = document.querySelectorAll('.progress-step');
    const processingLog = document.querySelector('.processing-log');
    const completionActions = document.getElementById('completion-actions');
    const viewTranscript = document.getElementById('view-transcript');
    const viewResults = document.getElementById('view-results');
    
    // Drag and drop functionality
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });
    
    uploadArea.addEventListener('dragleave', function() {
        uploadArea.classList.remove('drag-over');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length) {
            handleFileUpload(e.dataTransfer.files[0]);
        }
    });
    
    // File input change
    fileUpload.addEventListener('change', function() {
        if (this.files.length) {
            handleFileUpload(this.files[0]);
        }
    });
    
    // Handle file upload
    function handleFileUpload(file) {
        // Check file type
        const fileType = file.type;
        const validTypes = ['application/pdf', 'text/plain', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        
        if (!validTypes.includes(fileType)) {
            alert('Please upload a PDF, TXT, or DOCX file.');
            return;
        }
        
        // Update UI
        fileName.textContent = file.name;
        fileSize.textContent = formatFileSize(file.size);
        uploadArea.style.display = 'none';
        uploadPreview.style.display = 'block';
        nextStep1.disabled = false;
    }
    
    // Format file size
    function formatFileSize(bytes) {
        if (bytes < 1024) {
            return bytes + ' bytes';
        } else if (bytes < 1048576) {
            return (bytes / 1024).toFixed(1) + ' KB';
        } else {
            return (bytes / 1048576).toFixed(1) + ' MB';
        }
    }
    
    // Remove file
    removeFile.addEventListener('click', function() {
        uploadArea.style.display = 'block';
        uploadPreview.style.display = 'none';
        fileUpload.value = '';
        nextStep1.disabled = true;
    });
    
    // Back to dashboard
    backToDashboard.addEventListener('click', function() {
        window.location.href = 'dashboard.html';
    });
    
    // Next step 1
    nextStep1.addEventListener('click', function() {
        goToStep(2);
    });
    
    // Previous step 2
    prevStep2.addEventListener('click', function() {
        goToStep(1);
    });
    
    // Next step 2 (Process)
    nextStep2.addEventListener('click', function() {
        goToStep(3);
        simulateProcessing();
    });
    
    // Cancel processing
    cancelProcessing.addEventListener('click', function() {
        if (confirm('Are you sure you want to cancel processing? All progress will be lost.')) {
            goToStep(2);
            resetProcessingUI();
        }
    });
    
    // View transcript
    viewTranscript.addEventListener('click', function() {
        alert('In a real application, this would open the original transcript.');
    });
    
    // View results
    viewResults.addEventListener('click', function() {
        window.location.href = 'analysis.html';
    });
    
    // Go to step
    function goToStep(stepNumber) {
        // Update steps
        steps.forEach(step => {
            const stepNum = parseInt(step.getAttribute('data-step'));
            step.classList.remove('active');
            
            if (stepNum < stepNumber) {
                step.classList.add('completed');
            } else if (stepNum === stepNumber) {
                step.classList.add('active');
            } else {
                step.classList.remove('completed');
            }
        });
        
        // Update content panels
        stepContentPanels.forEach(panel => {
            panel.classList.remove('active');
            if (parseInt(panel.getAttribute('data-step-content')) === stepNumber) {
                panel.classList.add('active');
            }
        });
    }
    
    // Simulate processing
    function simulateProcessing() {
        // Reset UI
        resetProcessingUI();
        
        // Add initial log entry
        addLogEntry('Starting transcript processing...');
        
        // Simulate extraction (25%)
        setTimeout(() => {
            progressFill.style.width = '25%';
            progressSteps[0].classList.add('completed');
            progressSteps[1].classList.add('active');
            addLogEntry('Extracting text from PDF...');
            addLogEntry('Text extraction complete.');
            
            // Simulate analysis (50%)
            setTimeout(() => {
                progressFill.style.width = '50%';
                progressSteps[1].classList.add('completed');
                progressSteps[2].classList.add('active');
                addLogEntry('Analyzing transcript content...');
                addLogEntry('Identifying key themes and patterns...');
                addLogEntry('Generating SOAP components...');
                
                // Simulate generation (75%)
                setTimeout(() => {
                    progressFill.style.width = '75%';
                    progressSteps[2].classList.add('completed');
                    progressSteps[3].classList.add('active');
                    addLogEntry('Generating clinical progress note...');
                    addLogEntry('Creating supplemental analyses...');
                    
                    // Simulate completion (100%)
                    setTimeout(() => {
                        progressFill.style.width = '100%';
                        progressSteps[3].classList.add('completed');
                        processingSpinner.style.display = 'none';
                        successIcon.style.display = 'block';
                        processingStatusText.textContent = 'Processing Complete!';
                        processingDetails.textContent = 'Your clinical progress note has been generated successfully.';
                        completionActions.style.display = 'flex';
                        cancelProcessing.style.display = 'none';
                        addLogEntry('Compilation complete.');
                        addLogEntry('Clinical progress note ready for review.');
                    }, 2000);
                }, 3000);
            }, 3000);
        }, 2000);
    }
    
    // Reset processing UI
    function resetProcessingUI() {
        processingSpinner.style.display = 'block';
        successIcon.style.display = 'none';
        processingStatusText.textContent = 'Processing Transcript...';
        processingDetails.textContent = 'This may take a few minutes depending on the length of the transcript.';
        progressFill.style.width = '0%';
        progressSteps.forEach((step, index) => {
            step.classList.remove('active', 'completed');
            if (index === 0) {
                step.classList.add('active');
            }
        });
        processingLog.innerHTML = '';
        completionActions.style.display = 'none';
        cancelProcessing.style.display = 'block';
    }
    
    // Add log entry
    function addLogEntry(message) {
        const now = new Date();
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const timeString = `${minutes}:${seconds}`;
        
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';
        logEntry.innerHTML = `<span class="log-time">${timeString}</span><span class="log-message">${message}</span>`;
        
        processingLog.appendChild(logEntry);
        processingLog.scrollTop = processingLog.scrollHeight;
    }
});
