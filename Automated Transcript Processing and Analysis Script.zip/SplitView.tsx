import React from 'react';

interface SplitViewProps {
  analysis: any;
  transcript: any;
  activeSection: string;
  onSectionChange: (section: string) => void;
  onContentUpdate: (section: string, content: string) => void;
}

const SplitView: React.FC<SplitViewProps> = ({
  analysis,
  transcript,
  activeSection,
  onSectionChange,
  onContentUpdate
}) => {
  // Get content for the active section
  const getContent = () => {
    if (activeSection.includes('.')) {
      // Handle nested properties like supplementalAnalyses.keyPoints
      const [parent, child] = activeSection.split('.');
      return analysis[parent][child];
    } else {
      // Handle top-level properties
      return analysis[activeSection];
    }
  };

  // Handle content changes
  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onContentUpdate(activeSection, e.target.value);
  };

  return (
    <div className="split-view">
      <div className="split-view-sidebar">
        <div className="section-group">
          <h3>SOAP Note</h3>
          <ul>
            <li 
              className={activeSection === 'soapNote.subjective' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.subjective')}
            >
              Subjective
            </li>
            <li 
              className={activeSection === 'soapNote.objective' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.objective')}
            >
              Objective
            </li>
            <li 
              className={activeSection === 'soapNote.assessment' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.assessment')}
            >
              Assessment
            </li>
            <li 
              className={activeSection === 'soapNote.plan' ? 'active' : ''}
              onClick={() => onSectionChange('soapNote.plan')}
            >
              Plan
            </li>
          </ul>
        </div>
        
        <div className="section-group">
          <h3>Supplemental Analyses</h3>
          <ul>
            <li 
              className={activeSection === 'supplementalAnalyses.keyPoints' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.keyPoints')}
            >
              Key Points
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.significantQuotes' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.significantQuotes')}
            >
              Significant Quotes
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.tonalAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.tonalAnalysis')}
            >
              Tonal Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.thematicAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.thematicAnalysis')}
            >
              Thematic Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.sentimentAnalysis' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.sentimentAnalysis')}
            >
              Sentiment Analysis
            </li>
            <li 
              className={activeSection === 'supplementalAnalyses.narrativeSummary' ? 'active' : ''}
              onClick={() => onSectionChange('supplementalAnalyses.narrativeSummary')}
            >
              Narrative Summary
            </li>
          </ul>
        </div>
      </div>
      
      <div className="split-view-content">
        <div className="transcript-panel">
          <div className="panel-header">
            <h3>Transcript</h3>
          </div>
          <div className="transcript-content">
            <pre>{transcript.extractedText}</pre>
          </div>
        </div>
        
        <div className="analysis-panel">
          <div className="panel-header">
            <h3>{activeSection.includes('.') ? activeSection.split('.')[1] : activeSection}</h3>
          </div>
          <div className="analysis-content">
            <textarea
              className="analysis-textarea"
              value={getContent()}
              onChange={handleContentChange}
              placeholder="Content will appear here..."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SplitView;
