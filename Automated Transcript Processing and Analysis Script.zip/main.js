document.addEventListener('DOMContentLoaded', function() {
    // Modal functionality
    const loginModal = document.getElementById('login-modal');
    const signupModal = document.getElementById('signup-modal');
    const loginBtn = document.getElementById('login-btn');
    const signupBtn = document.getElementById('signup-btn');
    const getStartedBtn = document.getElementById('get-started-btn');
    const ctaBtn = document.getElementById('cta-btn');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const switchToSignup = document.getElementById('switch-to-signup');
    const switchToLogin = document.getElementById('switch-to-login');
    
    // Open login modal
    loginBtn.addEventListener('click', function() {
        loginModal.classList.add('active');
    });
    
    // Open signup modal
    signupBtn.addEventListener('click', function() {
        signupModal.classList.add('active');
    });
    
    // Get started button opens signup modal
    getStartedBtn.addEventListener('click', function() {
        signupModal.classList.add('active');
    });
    
    // CTA button opens signup modal
    ctaBtn.addEventListener('click', function() {
        signupModal.classList.add('active');
    });
    
    // Close modals
    closeModalBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            loginModal.classList.remove('active');
            signupModal.classList.remove('active');
        });
    });
    
    // Switch between login and signup
    switchToSignup.addEventListener('click', function(e) {
        e.preventDefault();
        loginModal.classList.remove('active');
        signupModal.classList.add('active');
    });
    
    switchToLogin.addEventListener('click', function(e) {
        e.preventDefault();
        signupModal.classList.remove('active');
        loginModal.classList.add('active');
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === loginModal) {
            loginModal.classList.remove('active');
        }
        if (e.target === signupModal) {
            signupModal.classList.remove('active');
        }
    });
    
    // Form submission
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        // For demo purposes, redirect to dashboard
        if (email && password) {
            window.location.href = 'dashboard.html';
        }
    });
    
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('signup-name').value;
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        const confirmPassword = document.getElementById('signup-confirm-password').value;
        
        // Basic validation
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        // For demo purposes, redirect to dashboard
        if (name && email && password) {
            window.location.href = 'dashboard.html';
        }
    });
    
    // Demo video functionality
    const videoPlaceholder = document.querySelector('.video-placeholder');
    const demoBtn = document.getElementById('demo-btn');
    const watchDemoBtn = document.getElementById('watch-demo-btn');
    
    function openDemoVideo() {
        // In a real implementation, this would open a video player or modal
        alert('Demo video would play here in the actual implementation');
    }
    
    videoPlaceholder.addEventListener('click', openDemoVideo);
    demoBtn.addEventListener('click', openDemoVideo);
    watchDemoBtn.addEventListener('click', openDemoVideo);
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            if (this.getAttribute('href') === '#') return;
            
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
