import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Navigate to transcript upload
  const handleUploadClick = () => {
    navigate('/upload');
  };

  // Navigate to settings
  const handleSettingsClick = () => {
    navigate('/settings');
  };

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>Welcome, {user?.firstName}</h1>
        <p className="dashboard-subtitle">
          Transform therapy transcripts into comprehensive clinical progress notes
        </p>
      </header>

      <div className="dashboard-cards">
        <div className="dashboard-card">
          <div className="card-icon upload-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="48" height="48">
              <path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/>
            </svg>
          </div>
          <h2>Upload Transcript</h2>
          <p>Upload a PDF transcript of a therapy session to generate a comprehensive clinical progress note.</p>
          <button 
            className="card-button"
            onClick={handleUploadClick}
            aria-label="Upload a new transcript"
          >
            Upload New Transcript
          </button>
        </div>

        <div className="dashboard-card">
          <div className="card-icon settings-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="48" height="48">
              <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
            </svg>
          </div>
          <h2>Configure Settings</h2>
          <p>Set up your API keys for OpenAI and Anthropic to enable AI-powered analysis of transcripts.</p>
          <button 
            className="card-button"
            onClick={handleSettingsClick}
            aria-label="Configure application settings"
          >
            Go to Settings
          </button>
        </div>
      </div>

      <section className="recent-activity">
        <h2>Recent Activity</h2>
        <div className="activity-empty">
          <p>No recent activity to display. Upload a transcript to get started.</p>
        </div>
      </section>

      <section className="dashboard-info">
        <div className="info-card">
          <h3>How It Works</h3>
          <ol>
            <li>
              <strong>Upload a Transcript</strong>
              <p>Upload a PDF file containing a therapy session transcript.</p>
            </li>
            <li>
              <strong>AI Analysis</strong>
              <p>Our system uses advanced AI to analyze the transcript and generate a comprehensive clinical note.</p>
            </li>
            <li>
              <strong>Review and Edit</strong>
              <p>Review the generated content, make any necessary edits, and ensure clinical accuracy.</p>
            </li>
            <li>
              <strong>Export</strong>
              <p>Export the final document in your preferred format for use in your clinical records.</p>
            </li>
          </ol>
        </div>

        <div className="info-card">
          <h3>Best Practices</h3>
          <ul>
            <li>Ensure transcripts are clear and complete before uploading</li>
            <li>Always review AI-generated content for accuracy</li>
            <li>Customize the output to match your clinical style</li>
            <li>Securely store your API keys in the settings</li>
            <li>Export only to secure, HIPAA-compliant destinations</li>
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
