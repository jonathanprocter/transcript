import crypto from 'crypto';
import config from '../config/config';

/**
 * Utility class for encrypting and decrypting sensitive data like API keys
 */
class EncryptionService {
  private algorithm = 'aes-256-cbc';
  private key = Buffer.from(config.encryptionKey, 'utf-8');
  
  /**
   * Encrypts sensitive data
   * @param text The plain text to encrypt
   * @returns The encrypted text
   */
  encrypt(text: string): string {
    // Create an initialization vector
    const iv = crypto.randomBytes(16);
    
    // Create cipher
    const cipher = crypto.createCipheriv(this.algorithm, this.key, iv);
    
    // Encrypt the text
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    // Return IV + encrypted data
    return iv.toString('hex') + ':' + encrypted;
  }
  
  /**
   * Decrypts encrypted data
   * @param encryptedText The encrypted text to decrypt
   * @returns The decrypted plain text
   */
  decrypt(encryptedText: string): string {
    // Split IV and encrypted data
    const textParts = encryptedText.split(':');
    const iv = Buffer.from(textParts[0], 'hex');
    const encryptedData = textParts[1];
    
    // Create decipher
    const decipher = crypto.createDecipheriv(this.algorithm, this.key, iv);
    
    // Decrypt the data
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }
}

export default new EncryptionService();
