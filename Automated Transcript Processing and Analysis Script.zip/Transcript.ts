import mongoose, { Document, Schema } from 'mongoose';

// Transcript interface
export interface ITranscript extends Document {
  userId: mongoose.Types.ObjectId;
  fileName: string;
  originalName: string;
  fileSize: number;
  mimeType: string;
  filePath: string;
  extractedText: string;
  processingStatus: 'pending' | 'extracting' | 'processing' | 'completed' | 'failed';
  processingError?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Transcript schema
const TranscriptSchema = new Schema<ITranscript>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    fileName: {
      type: String,
      required: true,
    },
    originalName: {
      type: String,
      required: true,
    },
    fileSize: {
      type: Number,
      required: true,
    },
    mimeType: {
      type: String,
      required: true,
    },
    filePath: {
      type: String,
      required: true,
    },
    extractedText: {
      type: String,
      default: '',
    },
    processingStatus: {
      type: String,
      enum: ['pending', 'extracting', 'processing', 'completed', 'failed'],
      default: 'pending',
    },
    processingError: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

// Create and export Transcript model
const Transcript = mongoose.model<ITranscript>('Transcript', TranscriptSchema);
export default Transcript;
