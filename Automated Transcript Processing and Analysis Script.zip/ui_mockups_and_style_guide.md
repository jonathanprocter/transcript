# Therapy Transcript Processor Web Application
# UI Mockups and Visual Style Guide

## 1. Visual Style Guide

### 1.1 Brand Identity

The Therapy Transcript Processor application's visual identity is designed to convey professionalism, trustworthiness, and calm efficiency. The visual language balances clinical precision with a warm, supportive feel that resonates with mental health professionals.

#### 1.1.1 Logo Concept

The logo combines a document icon with a subtle brain motif, representing the intersection of clinical documentation and psychological insight. The logo uses the primary teal color with accents of the secondary blue, conveying trust and professionalism.

#### 1.1.2 Brand Personality
- Professional without being cold
- Calming without being dull
- Efficient without feeling rushed
- Supportive without being patronizing
- Clinical without feeling sterile

### 1.2 Color Palette

#### 1.2.1 Primary Colors
- **Teal** (#2A9D8F): Primary brand color, used for main UI elements, primary buttons, and key interactive elements
- **Deep Blue** (#264653): Used for headers, navigation, and grounding elements
- **Warm Yellow** (#E9C46A): Used for highlights, accents, and attention-drawing elements

#### 1.2.2 Secondary Colors
- **Light Teal** (#8ECFC9): Used for secondary elements, backgrounds, and hover states
- **Muted Blue** (#457B9D): Used for secondary buttons and supporting elements
- **Soft Orange** (#F4A261): Used for warnings and secondary accents

#### 1.2.3 Neutral Colors
- **Off-White** (#F8F9FA): Primary background color
- **Light Gray** (#E9ECEF): Secondary background, cards, and form fields
- **Medium Gray** (#ADB5BD): Borders and dividers
- **Dark Gray** (#495057): Secondary text
- **Charcoal** (#212529): Primary text

#### 1.2.4 Functional Colors
- **Success Green** (#43AA8B): Confirmations and successful operations
- **Warning Orange** (#F4A261): Cautions and warnings
- **Error Red** (#E76F51): Errors and critical alerts
- **Info Blue** (#4EA5D9): Informational messages and help

#### 1.2.5 Color Usage Guidelines
- Maintain sufficient contrast ratios (minimum 4.5:1 for normal text, 3:1 for large text)
- Use color consistently across the application
- Never use color as the only means of conveying information
- Limit the use of accent colors to maintain visual hierarchy
- Ensure color combinations support the calm, professional aesthetic

### 1.3 Typography

#### 1.3.1 Primary Font: Inter
- A clean, professional sans-serif font with excellent readability
- Used for all UI elements, body text, and general content
- Weights: Regular (400), Medium (500), and Bold (700)

#### 1.3.2 Secondary Font: Merriweather
- A sophisticated serif font used for headings and emphasis
- Provides contrast to the primary font
- Weights: Regular (400) and Bold (700)

#### 1.3.3 Font Sizes
- **Heading 1**: 28px/1.2 (Merriweather Bold)
- **Heading 2**: 24px/1.25 (Merriweather Bold)
- **Heading 3**: 20px/1.3 (Merriweather Bold)
- **Heading 4**: 18px/1.4 (Inter Bold)
- **Heading 5**: 16px/1.5 (Inter Bold)
- **Body Large**: 18px/1.5 (Inter Regular)
- **Body**: 16px/1.5 (Inter Regular)
- **Body Small**: 14px/1.5 (Inter Regular)
- **Caption**: 12px/1.4 (Inter Medium)
- **Button**: 16px/1.25 (Inter Medium)

#### 1.3.4 Typography Guidelines
- Maintain consistent line heights for readability
- Use proper hierarchy to guide users through content
- Ensure sufficient contrast between text and background
- Limit the number of font sizes and weights for consistency
- Use appropriate letter spacing for different sizes

### 1.4 Iconography

#### 1.4.1 Icon Style
- Clean, outlined style with consistent stroke width
- Rounded corners for a friendly, approachable feel
- Simple, recognizable shapes with minimal detail
- Consistent padding within bounding box

#### 1.4.2 Icon Sizes
- **Large**: 32px (feature icons, empty states)
- **Medium**: 24px (navigation, major UI elements)
- **Small**: 16px (inline with text, minor UI elements)

#### 1.4.3 Icon Usage Guidelines
- Use icons consistently throughout the application
- Pair icons with text labels for clarity
- Maintain visual weight balance with surrounding elements
- Use animation sparingly and purposefully
- Ensure icons are recognizable and intuitive

### 1.5 Component Design

#### 1.5.1 Buttons
- **Primary Button**: Teal background, white text, subtle shadow
- **Secondary Button**: White background, teal border and text
- **Tertiary Button**: No background or border, teal text
- **Danger Button**: Error red background, white text
- **Disabled Button**: Light gray background, medium gray text

All buttons have rounded corners (8px radius), consistent padding (16px horizontal, 10px vertical), and subtle hover/active states.

#### 1.5.2 Form Elements
- **Text Input**: Light gray background, dark gray text, teal focus state
- **Dropdown**: Light gray background, dark icon, teal focus state
- **Checkbox/Radio**: Teal for selected state, light gray background
- **Toggle**: Teal background with white circle for on state
- **Slider**: Teal track and thumb, light gray background

All form elements have consistent sizing, clear focus states, and appropriate feedback for interactions.

#### 1.5.3 Cards and Containers
- **Card**: White background, subtle shadow, rounded corners (12px)
- **Container**: Light gray background, no shadow, rounded corners (8px)
- **Modal**: White background, medium shadow, rounded corners (12px)
- **Tooltip**: Dark gray background, white text, small arrow pointer

Consistent padding (24px) and spacing between elements (16px) throughout containers.

#### 1.5.4 Navigation Elements
- **Primary Navigation**: Deep blue background, white text and icons
- **Secondary Navigation**: White background, dark gray text, teal active state
- **Breadcrumbs**: Medium gray text, teal for current page
- **Tabs**: Underline style, teal for active tab

Clear visual indicators for current location and hover states.

### 1.6 Layout and Spacing

#### 1.6.1 Grid System
- 12-column grid for desktop layouts
- Responsive breakpoints at 576px, 768px, 992px, and 1200px
- Consistent gutters (24px) between columns

#### 1.6.2 Spacing Scale
- **4px**: Minimum spacing, used for tight relationships
- **8px**: Default spacing between related elements
- **16px**: Standard spacing between distinct elements
- **24px**: Spacing between groups of elements
- **32px**: Section spacing
- **48px**: Major section spacing
- **64px**: Page-level spacing

#### 1.6.3 Layout Guidelines
- Maintain consistent spacing throughout the application
- Use white space effectively to create visual hierarchy
- Ensure layouts are responsive and adapt to different screen sizes
- Group related elements together with consistent spacing
- Use alignment to create order and clarity

### 1.7 Imagery and Graphics

#### 1.7.1 Illustration Style
- Simple, clean illustrations with minimal detail
- Consistent color palette using brand colors
- Professional, clinical feel without being sterile
- Abstract representations of concepts rather than literal depictions

#### 1.7.2 Photography Guidelines
- Professional, well-lit images
- Neutral backgrounds that don't compete with UI elements
- Diverse representation of healthcare professionals
- Warm, calming tone that aligns with brand personality

#### 1.7.3 Data Visualization Style
- Clean, minimal charts and graphs
- Consistent use of brand colors for data series
- Clear labels and legends
- Appropriate chart types for different data relationships
- Interactive elements for exploring complex data

## 2. UI Mockups

### 2.1 Landing Page

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor                  Sign In    Sign Up     │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                                                                     │  │
│  │  Transform Therapy Transcripts into                                 │  │
│  │  Comprehensive Clinical Progress Notes                              │  │
│  │                                                                     │  │
│  │  A professional tool for mental health practitioners                │  │
│  │  that uses AI to generate detailed SOAP notes and                   │  │
│  │  supplemental analyses from session transcripts.                    │  │
│  │                                                                     │  │
│  │  [Get Started]    [Learn More]                                      │  │
│  │                                                                     │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│  ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐      │
│  │                   │  │                   │  │                   │      │
│  │  [ICON]           │  │  [ICON]           │  │  [ICON]           │      │
│  │  Upload PDF       │  │  AI-Powered       │  │  Comprehensive    │      │
│  │  Transcripts      │  │  Analysis         │  │  Documentation    │      │
│  │                   │  │                   │  │                   │      │
│  │  Easily upload    │  │  Advanced AI      │  │  Complete SOAP    │      │
│  │  therapy session  │  │  processes your   │  │  notes with key   │      │
│  │  transcripts in   │  │  transcripts to   │  │  points, quotes,  │      │
│  │  PDF format.      │  │  extract clinical │  │  and detailed     │      │
│  │                   │  │  insights.        │  │  analyses.        │      │
│  │                   │  │                   │  │                   │      │
│  └───────────────────┘  └───────────────────┘  └───────────────────┘      │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                                                                     │  │
│  │  "This tool has revolutionized my documentation process,            │  │
│  │  saving me hours each week while improving the quality              │  │
│  │  of my clinical notes."                                             │  │
│  │                                                                     │  │
│  │  - Dr. Sarah Johnson, Clinical Psychologist                         │  │
│  │                                                                     │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                                                                     │  │
│  │  Ready to transform your documentation process?                     │  │
│  │                                                                     │  │
│  │  [Sign Up Now]                                                      │  │
│  │                                                                     │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
├────────────────────────────────────────────────────────────────────────────┤
│  About Us    |    Privacy    |    Terms    |    Contact    |    Help       │
└────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Dashboard

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Welcome back, Dr. Smith                                      │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────┐  ┌─────────────────────────────┐ │
│            │ │                         │  │                             │ │
│  Progress  │ │  Recent Activity        │  │  Quick Actions              │ │
│  Notes     │ │                         │  │                             │ │
│            │ │  • John D. - Note       │  │  [Upload New Transcript]    │ │
│  Clients   │ │    completed 2h ago     │  │                             │ │
│            │ │                         │  │  [View Progress Notes]      │ │
│  Templates │ │  • Sarah M. - Processing│  │                             │ │
│            │ │    in progress          │  │  [Manage Templates]         │ │
│  Settings  │ │                         │  │                             │ │
│            │ │  • Alex T. - Transcript │  │  [API Settings]             │ │
│  Help      │ │    uploaded 1d ago      │  │                             │ │
│            │ │                         │  │                             │ │
│            │ │  [View All Activity]    │  │                             │ │
│            │ │                         │  │                             │ │
│            │ └─────────────────────────┘  └─────────────────────────────┘ │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Recent Clients                                         │  │
│            │ │                                                         │  │
│            │ │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐  │
│            │ │  │               │  │               │  │               │  │
│            │ │  │  John D.      │  │  Sarah M.     │  │  Alex T.      │  │
│            │ │  │  3 sessions   │  │  1 session    │  │  2 sessions   │  │
│            │ │  │  Last: Today  │  │  Last: Today  │  │  Last: 1d ago │  │
│            │ │  │               │  │               │  │               │  │
│            │ │  │ [View Notes]  │  │ [View Notes]  │  │ [View Notes]  │  │
│            │ │  │               │  │               │  │               │  │
│            │ │  └───────────────┘  └───────────────┘  └───────────────┘  │
│            │ │                                                         │  │
│            │ │  [View All Clients]                                     │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────┐  ┌─────────────────────────────┐ │
│            │ │                         │  │                             │ │
│            │ │  Processing Status      │  │  System Status              │ │
│            │ │                         │  │                             │ │
│            │ │  [Progress Bar: 75%]    │  │  API Status: Connected      │ │
│            │ │  Sarah M. - Session 1   │  │  OpenAI: Active             │ │
│            │ │  Estimated: 5 min       │  │  Anthropic: Active          │ │
│            │ │                         │  │  Last Sync: 5 min ago       │ │
│            │ │  [View Details]         │  │                             │ │
│            │ │                         │  │  [Check Status]             │ │
│            │ └─────────────────────────┘  └─────────────────────────────┘ │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.3 Transcript Upload Interface

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Upload Transcript                                            │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Progress  │ │  Drag and drop your PDF transcript here                 │  │
│  Notes     │ │  or                                                     │  │
│            │ │  [Browse Files]                                         │  │
│  Clients   │ │                                                         │  │
│            │ │  Supported format: PDF                                  │  │
│  Templates │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│  Settings  │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│  Help      │ │                                                         │  │
│            │ │  Client Information                                     │  │
│            │ │                                                         │  │
│            │ │  Client Name: [                    ] [+ New Client]     │  │
│            │ │                                                         │  │
│            │ │  Session Date: [MM/DD/YYYY      ]  Time: [HH:MM   ]    │  │
│            │ │                                                         │  │
│            │ │  Session Type: [Individual Therapy ▼]                   │  │
│            │ │                                                         │  │
│            │ │  Session Number: [     ]                                │  │
│            │ │                                                         │  │
│            │ │  Tags: [                                            ]   │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Processing Options                                     │  │
│            │ │                                                         │  │
│            │ │  ☑ Generate SOAP Note                                   │  │
│            │ │  ☑ Generate Key Points                                  │  │
│            │ │  ☑ Extract Significant Quotes                           │  │
│            │ │  ☑ Perform Tonal Analysis                               │  │
│            │ │  ☑ Perform Thematic Analysis                            │  │
│            │ │  ☑ Perform Sentiment Analysis                           │  │
│            │ │  ☑ Generate Comprehensive Narrative Summary             │  │
│            │ │                                                         │  │
│            │ │  Preferred AI Provider: [Anthropic (Claude) ▼]          │  │
│            │ │                                                         │  │
│            │ │  Processing Location: [Cloud ▼]                         │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Template: [Standard SOAP Note ▼]                       │  │
│            │ │                                                         │  │
│            │ │  [Cancel]                      [Upload and Process]     │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.4 PDF Preview and Validation

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Transcript Preview                                           │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Progress  │ │  client_session_05152025.pdf                            │  │
│  Notes     │ │                                                         │  │
│            │ │  ┌─────────────────────────────────────────────────┐   │  │
│  Clients   │ │  │                                                 │   │  │
│            │ │  │  [PDF PREVIEW]                                  │   │  │
│  Templates │ │  │                                                 │   │  │
│            │ │  │  Therapy Session Transcript                     │   │  │
│  Settings  │ │  │  Date: May 15, 2025                            │   │  │
│            │ │  │                                                 │   │  │
│  Help      │ │  │  Therapist: Dr. Smith                          │   │  │
│            │ │  │  Client: Sarah M.                              │   │  │
│            │ │  │                                                 │   │  │
│            │ │  │  Dr. Smith: Good morning, Sarah. How are you   │   │  │
│            │ │  │  feeling today?                                │   │  │
│            │ │  │                                                 │   │  │
│            │ │  │  Sarah: I've been better, to be honest. The    │   │  │
│            │ │  │  anxiety has been pretty bad this week...      │   │  │
│            │ │  │                                                 │   │  │
│            │ │  └─────────────────────────────────────────────────┘   │  │
│            │ │                                                         │  │
│            │ │  [Previous Page]  Page 1 of 5  [Next Page]             │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Extracted Text Quality                                 │  │
│            │ │                                                         │  │
│            │ │  Quality Assessment: [Good ●●●●○]                       │  │
│            │ │                                                         │  │
│            │ │  ⚠️ Some potential issues detected:                     │  │
│            │ │  • Page 3: Possible formatting issues                   │  │
│            │ │  • Page 4: Low confidence in speaker identification     │  │
│            │ │                                                         │  │
│            │ │  [View Extracted Text]                                  │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Back to Upload]                [Confirm and Process]  │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.5 Processing Status

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Processing Status                                            │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Progress  │ │  Sarah M. - Session on May 15, 2025                     │  │
│  Notes     │ │                                                         │  │
│            │ │  Overall Progress: [████████████████████░░░░░] 80%      │  │
│  Clients   │ │  Estimated Time Remaining: 3 minutes                    │  │
│            │ │                                                         │  │
│  Templates │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│  Settings  │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Help      │ │  Processing Pipeline                                    │  │
│            │ │                                                         │  │
│            │ │  ✓ PDF Text Extraction         [████████████████] 100%  │  │
│            │ │  ✓ Text Preprocessing          [████████████████] 100%  │  │
│            │ │  ✓ SOAP Note - Subjective      [████████████████] 100%  │  │
│            │ │  ✓ SOAP Note - Objective       [████████████████] 100%  │  │
│            │ │  ✓ SOAP Note - Assessment      [████████████████] 100%  │  │
│            │ │  ✓ SOAP Note - Plan            [████████████████] 100%  │  │
│            │ │  ✓ Key Points Extraction       [████████████████] 100%  │  │
│            │ │  ✓ Significant Quotes          [████████████████] 100%  │  │
│            │ │  → Tonal Analysis              [██████████░░░░░░]  60%  │  │
│            │ │  ○ Thematic Analysis           [░░░░░░░░░░░░░░░░]   0%  │  │
│            │ │  ○ Sentiment Analysis          [░░░░░░░░░░░░░░░░]   0%  │  │
│            │ │  ○ Narrative Summary           [░░░░░░░░░░░░░░░░]   0%  │  │
│            │ │  ○ Final Compilation           [░░░░░░░░░░░░░░░░]   0%  │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Processing Details                                     │  │
│            │ │                                                         │  │
│            │ │  API Provider: Anthropic (Claude-3-Opus)                │  │
│            │ │  Processing Mode: Cloud                                 │  │
│            │ │  Template: Standard SOAP Note                           │  │
│            │ │  Transcript Length: 3,245 words                         │  │
│            │ │  Processing Started: 2:15 PM                            │  │
│            │ │                                                         │  │
│            │ │  [View Processing Logs]                                 │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Cancel Processing]           [Continue in Background] │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.6 Results Viewer

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Progress Note: Sarah M. - May 15, 2025                       │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │ [Split View] [Edit Mode] [Print] [Export] [Save]        │  │
│  Progress  │ └─────────────────────────────────────────────────────────┘  │
│  Notes     │                                                               │
│            │ ┌────────────┬──────────────────────────────────────────────┐ │
│  Clients   │ │            │                                              │ │
│            │ │ SOAP Note  │ # Comprehensive Clinical Progress Note       │ │
│  Templates │ │ ▼          │ ## Sarah M.'s Therapy Session on May 15, 2025│ │
│            │ │ Subjective │                                              │ │
│  Settings  │ │ Objective  │ ### SUBJECTIVE                               │ │
│            │ │ Assessment │                                              │ │
│  Help      │ │ Plan       │ Sarah presented today reporting increased    │ │
│            │ │            │ anxiety symptoms over the past week. She     │ │
│            │ │ Analyses   │ described feeling "constantly on edge" and   │ │
│            │ │ ▼          │ experiencing difficulty sleeping, with       │ │
│            │ │ Key Points │ racing thoughts keeping her awake at night.  │ │
│            │ │ Quotes     │ She noted that her anxiety has been          │ │
│            │ │ Tonal      │ particularly triggered by an upcoming        │ │
│            │ │ Thematic   │ presentation at work, stating "I'm           │ │
│            │ │ Sentiment  │ convinced I'll freeze up and everyone will   │ │
│            │ │ Narrative  │ see how incompetent I really am."            │ │
│            │ │            │                                              │ │
│            │ │            │ Sarah also reported that she attempted to    │ │
│            │ │            │ use the breathing techniques discussed in    │ │
│            │ │            │ our previous session, but found it difficult │ │
│            │ │            │ to implement them when her anxiety was at    │ │
│            │ │            │ its peak. She expressed frustration with     │ │
│            │ │            │ herself for this perceived failure, saying   │ │
│            │ │            │ "I can't even do simple breathing exercises  │ │
│            │ │            │ right."                                      │ │
│            │ │            │                                              │ │
│            │ │            │ Additionally, Sarah mentioned ongoing        │ │
│            │ │            │ tension in her relationship with her mother, │ │
│            │ │            │ who she described as "constantly criticizing"│ │
│            │ │            │ her life choices. A recent phone call        │ │
│            │ │            │ escalated into an argument, which Sarah      │ │
│            │ │            │ identified as a significant contributor to   │ │
│            │ │            │ her current anxiety levels.                  │ │
│            │ │            │                                              │ │
│            │ │            │ [... continued ...]                          │ │
│            │ │            │                                              │ │
│            │ └────────────┴──────────────────────────────────────────────┘ │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Back to Dashboard]     [Edit]     [Export]     [Share]│  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.7 Split View Mode

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Progress Note: Sarah M. - May 15, 2025                       │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │ [Full View] [Edit Mode] [Print] [Export] [Save]         │  │
│  Progress  │ └─────────────────────────────────────────────────────────┘  │
│  Notes     │                                                               │
│            │ ┌────────────┬──────────────┬───────────────────────────────┐ │
│  Clients   │ │            │ TRANSCRIPT   │ ANALYSIS                      │ │
│            │ │ SOAP Note  │              │                               │ │
│  Templates │ │ ▼          │ Dr. Smith:   │ ### SUBJECTIVE                │ │
│            │ │ Subjective │ Good morning,│                               │ │
│  Settings  │ │ Objective  │ Sarah. How   │ Sarah presented today         │ │
│            │ │ Assessment │ are you      │ reporting increased anxiety   │ │
│  Help      │ │ Plan       │ feeling      │ symptoms over the past week.  │ │
│            │ │            │ today?       │ She described feeling         │ │
│            │ │ Analyses   │              │ "constantly on edge" and      │ │
│            │ │ ▼          │ Sarah: I've  │ experiencing difficulty       │ │
│            │ │ Key Points │ been better, │ sleeping, with racing         │ │
│            │ │ Quotes     │ to be honest.│ thoughts keeping her awake    │ │
│            │ │ Tonal      │ The anxiety  │ at night. She noted that      │ │
│            │ │ Thematic   │ has been     │ her anxiety has been          │ │
│            │ │ Sentiment  │ pretty bad   │ particularly triggered by     │ │
│            │ │ Narrative  │ this week.   │ an upcoming presentation      │ │
│            │ │            │ I'm          │ at work, stating "I'm         │ │
│            │ │            │ constantly   │ convinced I'll freeze up      │ │
│            │ │            │ on edge and  │ and everyone will see how     │ │
│            │ │            │ I can't      │ incompetent I really am."     │ │
│            │ │            │ sleep        │                               │ │
│            │ │            │ because my   │ Sarah also reported that      │ │
│            │ │            │ mind won't   │ she attempted to use the      │ │
│            │ │            │ shut off.    │ breathing techniques          │ │
│            │ │            │              │ discussed in our previous     │ │
│            │ │            │ Dr. Smith:   │ session, but found it         │ │
│            │ │            │ I'm sorry    │ difficult to implement        │ │
│            │ │            │ to hear      │ them when her anxiety was     │ │
│            │ │            │ that. Can    │ at its peak. She expressed    │ │
│            │ │            │ you tell me  │ frustration with herself      │ │
│            │ │            │ more about   │ for this perceived failure,   │ │
│            │ │            │ what's been  │ saying "I can't even do       │ │
│            │ │            │ triggering   │ simple breathing exercises    │ │
│            │ │            │ the anxiety? │ right."                       │ │
│            │ │            │              │                               │ │
│            │ └────────────┴──────────────┴───────────────────────────────┘ │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Back to Dashboard]     [Edit]     [Export]     [Share]│  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.8 Visualization View (Tonal Analysis)

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Tonal Analysis: Sarah M. - May 15, 2025                      │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │ [Text View] [Print] [Export] [Save]                     │  │
│  Progress  │ └─────────────────────────────────────────────────────────┘  │
│  Notes     │                                                               │
│            │ ┌────────────┬──────────────────────────────────────────────┐ │
│  Clients   │ │            │                                              │ │
│            │ │ SOAP Note  │ # Tonal Analysis                             │ │
│  Templates │ │ ▼          │                                              │ │
│            │ │ Subjective │ ## Session Timeline and Tonal Shifts         │ │
│  Settings  │ │ Objective  │                                              │ │
│            │ │ Assessment │ [VISUALIZATION: Interactive timeline showing │ │
│  Help      │ │ Plan       │ emotional tone throughout session with key   │ │
│            │ │            │ markers for significant shifts]              │ │
│            │ │ Analyses   │                                              │ │
│            │ │ ▼          │ ┌──────────────────────────────────────────┐ │ │
│            │ │ Key Points │ │                                          │ │ │
│            │ │ Quotes     │ │ Anxious                                  │ │ │
│            │ │ Tonal      │ │    ╭─╮                       ╭─╮         │ │ │
│            │ │ Thematic   │ │    │ │                       │ │         │ │ │
│            │ │ Sentiment  │ │    │ │     ╭───╮    ╭────╮   │ │         │ │ │
│            │ │ Narrative  │ │ ───┘ ╰─────╯   ╰────╯    ╰───╯ ╰─────────│ │ │
│            │ │            │ │                                          │ │ │
│            │ │            │ │ Neutral                                  │ │ │
│            │ │            │ │        ╭───╮         ╭───╮           ╭──│ │ │
│            │ │            │ │ ───────╯   ╰─────────╯   ╰───────────╯  │ │ │
│            │ │            │ │                                          │ │ │
│            │ │            │ │ Reflective                               │ │ │
│            │ │            │ │                ╭───╮                     │ │ │
│            │ │            │ │ ───────────────╯   ╰─────────────────────│ │ │
│            │ │            │ │                                          │ │ │
│            │ │            │ │ Hopeful                                  │ │ │
│            │ │            │ │                            ╭────────╮    │ │ │
│            │ │            │ │ ──────────────────────────╯        ╰────│ │ │
│            │ │            │ │                                          │ │ │
│            │ │            │ │ [Timeline markers showing session progress] │ │
│            │ │            │ └──────────────────────────────────────────┘ │ │
│            │ │            │                                              │ │
│            │ │            │ ## Major Tonal Shifts                        │ │
│            │ │            │                                              │ │
│            │ │            │ ### 1. From Anxious to Reflective            │ │
│            │ │            │ **Trigger**: Discussion of breathing techniques│ │
│            │ │            │ **Context**: When exploring why the breathing │ │
│            │ │            │ exercises weren't working for Sarah, her tone│ │
│            │ │            │ shifted from anxious frustration to a more   │ │
│            │ │            │ reflective quality as she gained insight into│ │
│            │ │            │ her perfectionist tendencies.                │ │
│            │ │            │                                              │ │
│            │ └────────────┴──────────────────────────────────────────────┘ │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.9 Progress Note Library

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Progress Note Library                                        │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │ [Filter ▼] [Sort: Date ▼] [Search Notes...]  [+ New]    │  │
│  Progress  │ └─────────────────────────────────────────────────────────┘  │
│  Notes     │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│  Clients   │ │                                                         │  │
│            │ │  View: [All Clients ▼]    Display: [List ⊟] [Cards ⊞]  │  │
│  Templates │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│  Settings  │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│  Help      │ │  Sarah M.                                               │  │
│            │ │  ┌─────────────────┐  ┌─────────────────┐              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  Session #1     │  │  Session #2     │              │  │
│            │ │  │  May 15, 2025   │  │  May 22, 2025   │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  Topics:        │  │  Topics:        │              │  │
│            │ │  │  • Anxiety      │  │  • Work stress  │              │  │
│            │ │  │  • Work         │  │  • Family       │              │  │
│            │ │  │  • Family       │  │  • Self-care    │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  [View]         │  │  [View]         │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  └─────────────────┘  └─────────────────┘              │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │  John D.                                                │  │
│            │ │  ┌─────────────────┐  ┌─────────────────┐  ┌───────────┐│  │
│            │ │  │                 │  │                 │  │           ││  │
│            │ │  │  Session #5     │  │  Session #6     │  │  Session #7││  │
│            │ │  │  May 10, 2025   │  │  May 17, 2025   │  │  May 24,  ││  │
│            │ │  │                 │  │                 │  │  2025     ││  │
│            │ │  │  Topics:        │  │  Topics:        │  │           ││  │
│            │ │  │  • Depression   │  │  • Medication   │  │  Topics:  ││  │
│            │ │  │  • Sleep        │  │  • Relationships│  │  • Progress││  │
│            │ │  │  • Exercise     │  │  • Goals        │  │  • Work   ││  │
│            │ │  │                 │  │                 │  │  • Future ││  │
│            │ │  │  [View]         │  │  [View]         │  │  [View]   ││  │
│            │ │  │                 │  │                 │  │           ││  │
│            │ │  └─────────────────┘  └─────────────────┘  └───────────┘│  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │  Alex T.                                                │  │
│            │ │  ┌─────────────────┐  ┌─────────────────┐              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  Session #1     │  │  Session #2     │              │  │
│            │ │  │  May 12, 2025   │  │  May 19, 2025   │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  Topics:        │  │  Topics:        │              │  │
│            │ │  │  • Intake       │  │  • Childhood    │              │  │
│            │ │  │  • History      │  │  • Trauma       │              │  │
│            │ │  │  • Goals        │  │  • Coping       │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  │  [View]         │  │  [View]         │              │  │
│            │ │  │                 │  │                 │              │  │
│            │ │  └─────────────────┘  └─────────────────┘              │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.10 Export Options Interface

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  Export Progress Note                                         │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Progress  │ │  Sarah M. - Session on May 15, 2025                     │  │
│  Notes     │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│  Clients   │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│  Templates │ │                                                         │  │
│            │ │  Export Format                                          │  │
│  Settings  │ │                                                         │  │
│            │ │  ○ Word Document (.docx)                                │  │
│  Help      │ │  ○ PDF Document (.pdf)                                  │  │
│            │ │  ○ Plain Text (.txt)                                    │  │
│            │ │  ○ HTML Document (.html)                                │  │
│            │ │                                                         │  │
│            │ │  Template: [Standard Clinical ▼]                        │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Content Options                                        │  │
│            │ │                                                         │  │
│            │ │  ☑ Include SOAP Note                                    │  │
│            │ │  ☑ Include Key Points                                   │  │
│            │ │  ☑ Include Significant Quotes                           │  │
│            │ │  ☐ Include Tonal Analysis                               │  │
│            │ │  ☐ Include Thematic Analysis                            │  │
│            │ │  ☐ Include Sentiment Analysis                           │  │
│            │ │  ☑ Include Narrative Summary                            │  │
│            │ │                                                         │  │
│            │ │  ☑ Include Header with Client Information               │  │
│            │ │  ☑ Include Footer with Page Numbers                     │  │
│            │ │  ☐ Include Original Transcript                          │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  Privacy Options                                        │  │
│            │ │                                                         │  │
│            │ │  ☑ Redact Personal Identifiers                          │  │
│            │ │    ☑ Names of non-clients                               │  │
│            │ │    ☑ Contact information                                │  │
│            │ │    ☑ Specific locations                                 │  │
│            │ │    ☐ Dates (except session date)                        │  │
│            │ │                                                         │  │
│            │ │  [Review Redactions]                                    │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Preview]                                [Export]      │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

### 2.11 API Settings Interface

```
┌────────────────────────────────────────────────────────────────────────────┐
│ [LOGO] Therapy Transcript Processor    [Search]    [Notifications]  [User] │
├────────────┬───────────────────────────────────────────────────────────────┤
│            │                                                               │
│  Dashboard │  API Settings                                                 │
│            │                                                               │
│  Transcripts│ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Progress  │ │  OpenAI API Configuration                               │  │
│  Notes     │ │                                                         │  │
│            │ │  API Key: [••••••••••••••••••••••••••••] [Update]       │  │
│  Clients   │ │                                                         │  │
│            │ │  Status: Connected                                      │  │
│  Templates │ │  Last Verified: Today at 2:15 PM                        │  │
│            │ │                                                         │  │
│  Settings  │ │  Default Model: [GPT-4-Turbo ▼]                         │  │
│  ▼         │ │                                                         │  │
│  API       │ │  [Test Connection]                                      │  │
│  Profile   │ │                                                         │  │
│  Security  │ └─────────────────────────────────────────────────────────┘  │
│  Privacy   │                                                               │
│  Billing   │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│  Help      │ │  Anthropic API Configuration                            │  │
│            │ │                                                         │  │
│            │ │  API Key: [••••••••••••••••••••••••••••] [Update]       │  │
│            │ │                                                         │  │
│            │ │  Status: Connected                                      │  │
│            │ │  Last Verified: Today at 2:15 PM                        │  │
│            │ │                                                         │  │
│            │ │  Default Model: [Claude-3-Opus ▼]                       │  │
│            │ │                                                         │  │
│            │ │  [Test Connection]                                      │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  API Usage Preferences                                  │  │
│            │ │                                                         │  │
│            │ │  Preferred Provider: [Anthropic ▼]                      │  │
│            │ │                                                         │  │
│            │ │  Fallback Strategy:                                     │  │
│            │ │  ○ Always use preferred provider only                   │  │
│            │ │  ● Attempt fallback to secondary provider               │  │
│            │ │  ○ Use both providers and select best result            │  │
│            │ │                                                         │  │
│            │ │  Processing Location:                                   │  │
│            │ │  ● Cloud (Server-side processing)                       │  │
│            │ │  ○ Local (Browser-based processing)                     │  │
│            │ │  ○ Hybrid (Sensitive data processed locally)            │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  API Usage Statistics                                   │  │
│            │ │                                                         │  │
│            │ │  This Month:                                            │  │
│            │ │  • OpenAI: 25 requests ($3.75 estimated)                │  │
│            │ │  • Anthropic: 42 requests ($8.40 estimated)             │  │
│            │ │                                                         │  │
│            │ │  [View Detailed Usage]                                  │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
│            │ ┌─────────────────────────────────────────────────────────┐  │
│            │ │                                                         │  │
│            │ │  [Cancel]                                     [Save]    │  │
│            │ │                                                         │  │
│            │ └─────────────────────────────────────────────────────────┘  │
│            │                                                               │
└────────────┴───────────────────────────────────────────────────────────────┘
```

## 3. Responsive Design Considerations

### 3.1 Mobile View Adaptations

The application will adapt to smaller screens with the following modifications:

1. **Navigation**: Side navigation collapses to a hamburger menu
2. **Layout**: Single column layout with stacked components
3. **Typography**: Slightly reduced font sizes with maintained readability
4. **Touch Targets**: Enlarged interactive elements for touch input
5. **Split View**: Automatically switches to tabbed interface instead of side-by-side
6. **Visualizations**: Simplified for smaller screens with option to view full version

### 3.2 Tablet View Adaptations

For medium-sized screens, the application will implement:

1. **Navigation**: Collapsible side navigation with icons and labels
2. **Layout**: Flexible grid that adapts to available space
3. **Split View**: Optional side-by-side view with adjustable split
4. **Modals**: Optimized size for tablet screens
5. **Touch Support**: Full touch gesture support for navigation and interaction

### 3.3 Accessibility Considerations

The application will maintain accessibility across all screen sizes:

1. **Color Contrast**: Maintained minimum contrast ratios
2. **Text Scaling**: Support for browser text scaling
3. **Keyboard Navigation**: Full keyboard support on all devices
4. **Screen Reader Support**: Semantic HTML and ARIA attributes
5. **Focus Indicators**: Clear visual focus indicators for all interactive elements

## 4. Animation and Transition Specifications

### 4.1 Page Transitions

- **Fade Transition**: Subtle fade (150ms) between major page changes
- **Slide Transition**: Directional slides for sequential workflows
- **Cross-Fade**: Smooth transition between related content areas

### 4.2 Component Animations

- **Loading States**: Pulsing animation for loading indicators
- **Progress Indicators**: Smooth filling animation for progress bars
- **Expansion/Collapse**: Natural easing for expanding/collapsing sections
- **Hover Effects**: Subtle scale or color change on hover (100ms)
- **Button Feedback**: Slight depression effect on click

### 4.3 Visualization Animations

- **Chart Entry**: Progressive reveal of data visualizations
- **Timeline Scrubbing**: Smooth transitions when navigating timeline
- **Focus Effects**: Highlight effect when focusing on specific data points
- **Tooltip Reveal**: Smooth fade in/out for tooltips (200ms)

## 5. Implementation Guidelines

### 5.1 Design System Implementation

1. Create a comprehensive component library implementing all UI elements
2. Establish consistent naming conventions for components and styles
3. Document usage guidelines for each component
4. Implement theme provider for consistent styling
5. Create responsive mixins for adapting to different screen sizes

### 5.2 Accessibility Implementation

1. Implement proper semantic HTML throughout the application
2. Add appropriate ARIA attributes for complex components
3. Ensure keyboard navigability for all interactive elements
4. Test with screen readers and keyboard-only navigation
5. Implement focus management for modals and dynamic content

### 5.3 Animation Implementation

1. Use CSS transitions for simple animations
2. Implement React Spring or Framer Motion for complex animations
3. Ensure animations respect reduced motion preferences
4. Optimize performance by avoiding layout thrashing
5. Test animations across different devices and browsers

## 6. Conclusion

This UI mockups and visual style guide provides a comprehensive blueprint for implementing the Therapy Transcript Processor web application with a professional, calming aesthetic appropriate for mental health professionals. The design balances clinical precision with warmth and approachability, creating an interface that supports the complex workflows of transcript processing and clinical documentation.

The mockups cover all major application screens and user flows, with detailed specifications for typography, color, component design, and responsive behavior. Implementation should follow the guidelines provided to ensure consistency, accessibility, and a polished user experience across all devices.

The visual language established in this guide should be maintained throughout the application development process, with regular validation against the design specifications to ensure the final product meets the high standards required for a professional clinical tool.
