import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ErrorAlert from '../components/ErrorAlert';
import LoadingSpinner from '../components/LoadingSpinner';

const AnalysisView: React.FC = () => {
  const [analyzing, setAnalyzing] = useState(false);
  const [provider, setProvider] = useState<'openai' | 'anthropic'>('openai');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState<string>('');
  
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const handleStartAnalysis = async () => {
    try {
      // Validate user is logged in
      if (!user) {
        setError('You must be logged in to perform analysis');
        return;
      }
      
      // Check if API key is configured - with proper null check
      const hasOpenAiKey = user?.hasOpenAiKey || false;
      const hasAnthropicKey = user?.hasAnthropicKey || false;
      
      if ((provider === 'openai' && !hasOpenAiKey) || 
          (provider === 'anthropic' && !hasAnthropicKey)) {
        setError(`${provider === 'openai' ? 'OpenAI' : 'Anthropic'} API key not configured. Please add it in Settings.`);
        return;
      }
      
      setAnalyzing(true);
      setError(null);
      setProgress(0);
      
      // Simulate analysis process
      const steps = [
        'Preprocessing transcript',
        'Generating SOAP components',
        'Performing tonal analysis',
        'Identifying key themes',
        'Conducting sentiment analysis',
        'Extracting significant quotes',
        'Compiling comprehensive narrative',
        'Finalizing clinical documentation'
      ];
      
      let currentStepIndex = 0;
      
      const analysisInterval = setInterval(() => {
        if (currentStepIndex < steps.length) {
          setCurrentStep(steps[currentStepIndex]);
          setProgress(Math.round((currentStepIndex + 1) / steps.length * 100));
          currentStepIndex++;
        } else {
          clearInterval(analysisInterval);
          
          // Navigate to results page
          setTimeout(() => {
            setAnalyzing(false);
            navigate('/analysis/123');
          }, 500);
        }
      }, 1500);
      
    } catch (err: any) {
      setAnalyzing(false);
      setError(err.message || 'Failed to start analysis');
    }
  };
  
  return (
    <div className="analysis-container">
      <header className="analysis-header">
        <h1>Generate Clinical Analysis</h1>
        <p className="analysis-description">
          Use AI to analyze the transcript and generate a comprehensive clinical progress note
        </p>
      </header>
      
      {error && (
        <ErrorAlert 
          message={error} 
          onDismiss={() => setError(null)} 
        />
      )}
      
      <div className="analysis-card">
        <div className="provider-selection">
          <h2>Select AI Provider</h2>
          <p className="provider-description">
            Choose which AI model to use for generating the clinical analysis
          </p>
          
          <div className="provider-options">
            <label className={`provider-option ${provider === 'openai' ? 'selected' : ''}`}>
              <input
                type="radio"
                name="provider"
                value="openai"
                checked={provider === 'openai'}
                onChange={() => setProvider('openai')}
                disabled={analyzing}
              />
              <div className="provider-content">
                <div className="provider-icon">
                  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24">
                    <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.5093-2.6067-1.4997z" fill="currentColor"/>
                  </svg>
                </div>
                <div className="provider-info">
                  <h3>OpenAI GPT-4</h3>
                  <p>Advanced language model with strong clinical understanding</p>
                  <span className="provider-status">
                    {user?.hasOpenAiKey ? 'API Key Configured' : 'API Key Not Configured'}
                  </span>
                </div>
              </div>
            </label>
            
            <label className={`provider-option ${provider === 'anthropic' ? 'selected' : ''}`}>
              <input
                type="radio"
                name="provider"
                value="anthropic"
                checked={provider === 'anthropic'}
                onChange={() => setProvider('anthropic')}
                disabled={analyzing}
              />
              <div className="provider-content">
                <div className="provider-icon">
                  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="24" height="24">
                    <path d="M12 2L2 7.5L12 13L22 7.5L12 2Z" fill="currentColor"/>
                    <path d="M2 16.5L12 22L22 16.5V7.5L12 13L2 7.5V16.5Z" fill="currentColor" fillOpacity="0.5"/>
                  </svg>
                </div>
                <div className="provider-info">
                  <h3>Anthropic Claude 3</h3>
                  <p>Specialized in nuanced clinical reasoning and analysis</p>
                  <span className="provider-status">
                    {user?.hasAnthropicKey ? 'API Key Configured' : 'API Key Not Configured'}
                  </span>
                </div>
              </div>
            </label>
          </div>
        </div>
        
        {analyzing && (
          <div className="analysis-progress">
            <h3>Analysis in Progress</h3>
            <p className="current-step">{currentStep}</p>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="progress-text">{progress}% Complete</div>
          </div>
        )}
        
        <div className="analysis-actions">
          <button
            className="btn btn-primary start-analysis-button"
            onClick={handleStartAnalysis}
            disabled={analyzing}
          >
            {analyzing ? (
              <>
                <LoadingSpinner size="small" />
                <span>Analyzing...</span>
              </>
            ) : (
              'Start Analysis'
            )}
          </button>
        </div>
      </div>
      
      <div className="analysis-info">
        <h3>About the Analysis Process</h3>
        <p>
          The AI will analyze the transcript and generate a comprehensive clinical progress note,
          including SOAP components, supplemental analyses, and a narrative summary. This process
          typically takes 1-2 minutes depending on the length of the transcript.
        </p>
        
        <div className="analysis-steps">
          <div className="step">
            <div className="step-number">1</div>
            <div className="step-content">
              <h4>Preprocessing</h4>
              <p>The transcript is cleaned and prepared for analysis</p>
            </div>
          </div>
          
          <div className="step">
            <div className="step-number">2</div>
            <div className="step-content">
              <h4>SOAP Generation</h4>
              <p>Subjective, Objective, Assessment, and Plan components are created</p>
            </div>
          </div>
          
          <div className="step">
            <div className="step-number">3</div>
            <div className="step-content">
              <h4>Supplemental Analyses</h4>
              <p>Tonal, thematic, and sentiment analyses are performed</p>
            </div>
          </div>
          
          <div className="step">
            <div className="step-number">4</div>
            <div className="step-content">
              <h4>Compilation</h4>
              <p>All components are compiled into a comprehensive clinical document</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;
