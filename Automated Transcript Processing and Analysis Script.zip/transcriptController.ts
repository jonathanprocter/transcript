import { Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { exec } from 'child_process';
import util from 'util';
import config from '../config/config';
import Transcript from '../models/Transcript';

// Convert exec to Promise-based
const execPromise = util.promisify(exec);

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadsDir = path.join(__dirname, '../../', config.uploadDir);
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    // Create unique filename with original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `transcript-${uniqueSuffix}${ext}`);
  }
});

// File filter to only allow PDFs
const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Only PDF files are allowed'));
  }
};

// Configure upload middleware
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: config.maxUploadSize // Default 10MB
  }
});

/**
 * Transcript controller for handling file uploads and PDF processing
 */
class TranscriptController {
  /**
   * Upload a transcript file
   */
  uploadTranscript = [
    upload.single('transcript'),
    async (req: Request, res: Response) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: 'No file uploaded' });
        }

        const user = req.user!;
        
        // Create transcript record
        const transcript = new Transcript({
          userId: user._id,
          fileName: req.file.filename,
          originalName: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          filePath: req.file.path,
          processingStatus: 'pending'
        });
        
        await transcript.save();
        
        // Start text extraction in background
        this.extractTextFromPdf(transcript._id);
        
        res.status(201).json({
          message: 'Transcript uploaded successfully',
          transcript: {
            id: transcript._id,
            fileName: transcript.originalName,
            status: transcript.processingStatus,
            createdAt: transcript.createdAt
          }
        });
      } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ message: 'Server error during upload' });
      }
    }
  ];
  
  /**
   * Extract text from PDF using poppler-utils
   */
  private async extractTextFromPdf(transcriptId: string) {
    try {
      // Get transcript
      const transcript = await Transcript.findById(transcriptId);
      
      if (!transcript) {
        console.error(`Transcript not found: ${transcriptId}`);
        return;
      }
      
      // Update status
      transcript.processingStatus = 'extracting';
      await transcript.save();
      
      // Use pdftotext from poppler-utils to extract text
      const outputPath = transcript.filePath + '.txt';
      
      // Execute pdftotext command
      const { stdout, stderr } = await execPromise(`pdftotext -layout "${transcript.filePath}" "${outputPath}"`);
      
      if (stderr) {
        console.error(`pdftotext error: ${stderr}`);
        transcript.processingStatus = 'failed';
        transcript.processingError = `PDF extraction error: ${stderr}`;
        await transcript.save();
        return;
      }
      
      // Read extracted text
      const extractedText = fs.readFileSync(outputPath, 'utf8');
      
      // Update transcript with extracted text
      transcript.extractedText = extractedText;
      transcript.processingStatus = 'completed';
      await transcript.save();
      
      // Clean up temporary text file
      fs.unlinkSync(outputPath);
      
      console.log(`Successfully extracted text from transcript: ${transcriptId}`);
    } catch (error) {
      console.error('Text extraction error:', error);
      
      // Update transcript with error
      const transcript = await Transcript.findById(transcriptId);
      if (transcript) {
        transcript.processingStatus = 'failed';
        transcript.processingError = `PDF extraction error: ${error}`;
        await transcript.save();
      }
    }
  }
  
  /**
   * Get transcript by ID
   */
  async getTranscript(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      
      // Find transcript
      const transcript = await Transcript.findOne({
        _id: id,
        userId: user._id
      });
      
      if (!transcript) {
        return res.status(404).json({ message: 'Transcript not found' });
      }
      
      res.status(200).json({
        transcript: {
          id: transcript._id,
          fileName: transcript.originalName,
          fileSize: transcript.fileSize,
          status: transcript.processingStatus,
          extractedText: transcript.extractedText,
          error: transcript.processingError,
          createdAt: transcript.createdAt,
          updatedAt: transcript.updatedAt
        }
      });
    } catch (error) {
      console.error('Get transcript error:', error);
      res.status(500).json({ message: 'Server error retrieving transcript' });
    }
  }
  
  /**
   * Get all transcripts for current user
   */
  async getAllTranscripts(req: Request, res: Response) {
    try {
      const user = req.user!;
      
      // Find all transcripts for user
      const transcripts = await Transcript.find({ userId: user._id })
        .sort({ createdAt: -1 });
      
      res.status(200).json({
        transcripts: transcripts.map(t => ({
          id: t._id,
          fileName: t.originalName,
          status: t.processingStatus,
          createdAt: t.createdAt
        }))
      });
    } catch (error) {
      console.error('Get all transcripts error:', error);
      res.status(500).json({ message: 'Server error retrieving transcripts' });
    }
  }
  
  /**
   * Delete transcript
   */
  async deleteTranscript(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const user = req.user!;
      
      // Find transcript
      const transcript = await Transcript.findOne({
        _id: id,
        userId: user._id
      });
      
      if (!transcript) {
        return res.status(404).json({ message: 'Transcript not found' });
      }
      
      // Delete file
      if (fs.existsSync(transcript.filePath)) {
        fs.unlinkSync(transcript.filePath);
      }
      
      // Delete transcript from database
      await Transcript.deleteOne({ _id: id });
      
      res.status(200).json({ message: 'Transcript deleted successfully' });
    } catch (error) {
      console.error('Delete transcript error:', error);
      res.status(500).json({ message: 'Server error deleting transcript' });
    }
  }
}

export default new TranscriptController();
